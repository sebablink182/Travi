// Screenshot dei fogli nuovi, dentro l'app VERA (stesso banco di prova di
// prova.js): apre il foglio chiesto e scatta.
//   node _tools/scatta-fogli.js frasi /tmp/frasi.png
const fs = require('fs');
const path = require('path');
const http = require('http');
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');

const RADICE = path.resolve(__dirname, '..');
const PORTA = 8907;
const FINTI = {
  trip: { start: '2027-05-05', end: '2027-05-07' },
  days: [
    { id: 'g1', date: '2027-05-05', city: 'Tokyo', theme: 'Arrivo' },
    { id: 'g2', date: '2027-05-06', city: 'Tokyo', theme: 'Asakusa' },
    { id: 'g3', date: '2027-05-07', city: 'Kyoto', theme: 'Templi' },
  ],
  stops: [
    { id: 's1', day: 'g1', time: '10:00', title: 'Senso-ji', sub: 'Asakusa, Tokyo', cat: 'temple', dur: 60, tmin: 0, tmode: 'walk', lat: 35.7148, lon: 139.7967 },
  ],
};

const app = fs.readFileSync(path.join(RADICE, 'js/app.js'), 'utf8');
const stub = `const auth = {}, db = {};
const onAuthStateChanged = (a, cb) => cb({ uid: 'prova' });
const signInWithEmailAndPassword = () => Promise.resolve();
const signOut = () => {};
const doc = () => ({});
const getDoc = () => Promise.resolve({ exists: () => true, data: () => (${JSON.stringify(FINTI)}) });
const setDoc = () => Promise.resolve();
const onSnapshot = (r, cb) => { cb({ exists: () => false }); return () => {}; };

`;
fs.writeFileSync(path.join(RADICE, '_shot-app.mjs'), stub + app.slice(app.indexOf('(function () {')));
let html = fs.readFileSync(path.join(RADICE, 'index.html'), 'utf8');
html = html.replace('<script type="module" src="js/app.js"></script>', '<script type="module" src="_shot-app.mjs"></script>');
fs.writeFileSync(path.join(RADICE, '_shot.html'), html);

const TIPI = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.jpg': 'image/jpeg', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const f = path.join(RADICE, decodeURIComponent(req.url.split('?')[0]));
  fs.readFile(f, (err, d) => {
    if (err) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { 'Content-Type': TIPI[path.extname(f)] || 'application/octet-stream' });
    res.end(d);
  });
}).listen(PORTA);

const QUALE = {
  frasi: 'riga-frasi',
  cambio: 'riga-cambio',
  diario: 'riga-diario',
  altro: null,
  idee: 'btn-idee',
};

(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 393, height: 852 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
  await p.goto(`http://localhost:${PORTA}/_shot.html`, { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(2200);
  const vista = process.argv[2] === 'idee' ? 'preferiti' : 'altro';
  await p.evaluate((v) => document.querySelector(`.tab[data-view="${v}"]`).click(), vista);
  await p.waitForTimeout(400);
  const riga = QUALE[process.argv[2]];
  if (riga) {
    await p.evaluate((r) => document.getElementById(r).click(), riga);
    await p.waitForTimeout(700);
  }
  if (process.argv[2] === 'cerca') {
    await p.evaluate(() => {
      document.querySelector('.cerca-apri').click();
      const i = document.getElementById('cerca-tutto');
      i.value = 'senso'; i.dispatchEvent(new Event('input'));
    });
    await p.waitForTimeout(600);
  }
  await p.screenshot({ path: process.argv[3] });
  await b.close();
  server.close();
  ['_shot-app.mjs', '_shot.html'].forEach((f) => { try { fs.unlinkSync(path.join(RADICE, f)); } catch (e) {} });
})();
