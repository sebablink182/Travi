#!/usr/bin/env python3
"""
Travi — anteprima statica delle schermate, per GUARDARE prima di pubblicare.

Perché esiste: l'app vera sta dietro il login Firebase e i dati del viaggio non
sono pubblicati, quindi non si può aprire in un browser di prova. Questo
strumento ritaglia il markup vero da index.html, ci mette dentro dati finti e
lo salva come pagina autonoma: si apre con un browser headless, si fa uno
screenshot a misura iPhone e si guarda com'è venuta PRIMA di mandarla sul
telefono. È lo stesso metodo di pillola.html/palette.html, applicato al layout.

Uso (dentro il container di lavoro, con playwright installato):
    python3 _tools/anteprima.py            # genera _prev-*.html
    node _tools/scatta.js _prev-home.html /tmp/home.png [scrollY]

I file _prev-*.html sono usa e getta: non vanno pubblicati (vedi .gitignore).
"""
import re, sys, os

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
html = open("index.html").read()
css = open("style.css").read()
sprite = html[html.index('<svg width="0" height="0" style="position:absolute" aria-hidden="true">'):
              html.index("</svg>", html.index('aria-hidden="true"')) + 6]
tabbar = re.search(r'(<div class="tabbar">.*?</div>\s*</div>)', html, re.S).group(1)

def pagina(corpo, extra=""):
    return ('<!doctype html><html lang="it"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<style>%s</style></head><body>%s<div class="stage"><div class="shell">%s</div></div>%s</body></html>'
            % (css, sprite, corpo, extra))

# --- HOME, con dati finti al posto di quelli veri -------------------------
home = re.search(r'<!-- HOME -->(.*?)<!-- ITINERARIO -->', html, re.S).group(1)
for cerca, metti in [
    ('id="hero-big">–', 'id="hero-big">243'),
    ('id="hero-lbl">Sto calcolando il conto alla rovescia…', 'id="hero-lbl">giorni al vostro primo passo in Giappone.'),
    ('id="hero-date">–', 'id="hero-date">5 maggio 2027 · Arrivo a Tokyo'),
    ('id="hero-phase">Honeymoon in Japan', 'id="hero-phase">Buongiorno, Sebastian &amp; Alessandra'),
    ('id="next-title">–', 'id="next-title">Senso-ji'),
    ('id="next-meta">–', 'id="next-meta">09:15 · Asakusa, Tokyo'),
    ('id="home-count">0 <small>', 'id="home-count">5 <small>'),
    ('id="home-pct">0%', 'id="home-pct">40%'),
    ('id="home-stops-total">–', 'id="home-stops-total">52'),
    ('id="home-done-lbl">Nessuna tappa completata ancora', 'id="home-done-lbl">2 di 5 completate'),
    ('<circle class="ring-fg" id="ring-fg" cx="50" cy="50" r="42"/>',
     '<circle class="ring-fg" id="ring-fg" cx="50" cy="50" r="42" style="stroke-dashoffset:158.3"/>'),
    ('<div class="glyph" id="next-glyph">',
     '<div class="glyph has-img" id="next-glyph" style="background-image:url(\'assets/img/senso-ji.jpg\')">'),
]:
    home = home.replace(cerca, metti)
open("_prev-home.html", "w").write(pagina(home + tabbar))

# --- FOGLIO TAPPA, come lo apre openSheet() su una tappa esistente --------
sheet = re.search(r'(<div class="sheet" id="sheet">.*?)\n<div class="sheet" id="fav-sheet">', html, re.S).group(1)
for cerca, metti in [
    ('class="sheet" id="sheet"', 'class="sheet show" id="sheet"'),
    ('<div class="sheet-hero" id="sheet-hero" hidden>', '<div class="sheet-hero" id="sheet-hero">'),
    ('<div class="sheet-hero-img" id="sheet-hero-img"></div>',
     '<div class="sheet-hero-img" style="background-image:url(\'assets/img/kiyomizu-dera.jpg\')"></div>'),
    ('<div class="sheet-hero-prio" id="sheet-hero-prio" hidden>', '<div class="sheet-hero-prio">'),
    ('id="sheet-hero-title">–', '>Kiyomizu-dera'),
    ('id="sheet-hero-sub">–', '>11:30 · Higashiyama, Kyoto'),
    ('>Tappa<', '>Modifica tappa<'),
    ('<a class="tondo-link" id="link-gmaps" target="_blank" rel="noopener" href="#" hidden',
     '<a class="tondo-link" id="link-gmaps" href="#"'),
    ('<div id="sez-posto">', '<div id="sez-posto" hidden>'),
    ('<div class="pickrow" id="f-priorita"></div>',
     '<div class="pickrow"><div class="pick sel">Imperdibile</div><div class="pick">Normale</div><div class="pick">Se avanza</div></div>'),
    ('<div class="pickrow" id="f-duration-chips"></div>',
     '<div class="pickrow"><div class="pick">15 min</div><div class="pick">30</div><div class="pick">45</div>'
     '<div class="pick sel">1 h</div><div class="pick">1½ h</div><div class="pick">2 h+</div></div>'),
]:
    sheet = sheet.replace(cerca, metti)
open("_prev-sheet.html", "w").write(pagina("", '<div class="backdrop show"></div>' + sheet))

print("generati: _prev-home.html, _prev-sheet.html")
