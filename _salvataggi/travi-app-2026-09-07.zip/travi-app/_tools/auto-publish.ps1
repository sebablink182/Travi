﻿# Travi - auto-publish
# Gira in background per sempre: controlla la cartella travi-app, e se trova
# modifiche (nuovi file scritti da Claude) fa da solo git add + commit + push
# su GitHub, senza che nessuno debba aprire PowerShell.
#
# Non serve capirlo o modificarlo: basta lasciarlo li'. Si avvia da solo ad
# ogni accensione del PC (vedi setup-autopublish.ps1).

$repoPath      = Join-Path $env:USERPROFILE "Desktop\travi-app"
$logPath       = Join-Path $repoPath "_tools\autopublish.log"
$heartbeatPath = Join-Path $repoPath "_tools\heartbeat.txt"

function Write-Log($msg) {
    $line = "{0} - {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    Add-Content -Path $logPath -Value $line -Encoding UTF8
}

Write-Log "Avviato (repo: $repoPath)"
Set-Content -Path $heartbeatPath -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -Encoding UTF8

while ($true) {
    try {
        if (-not (Test-Path $repoPath)) {
            Write-Log "ERRORE: cartella non trovata: $repoPath"
            Start-Sleep -Seconds 30
            continue
        }

        Set-Location $repoPath

        $gitCmd = Get-Command git -ErrorAction SilentlyContinue
        if (-not $gitCmd) {
            Write-Log "ERRORE: git non trovato nel PATH"
            Start-Sleep -Seconds 30
            continue
        }

        # git status --porcelain torna un array di righe in PowerShell: lo
        # uniamo in una singola stringa, altrimenti il confronto "-eq" tra
        # due array qui sotto non funziona come ci si aspetta (non confronta
        # il contenuto) e sembrerebbe sempre "instabile"
        $status1 = (git status --porcelain 2>$null) -join "`n"

        if ($status1) {
            # aspetta un attimo: se Claude sta scrivendo piu' file di fila,
            # cosi' li prendiamo tutti insieme in un solo commit invece di
            # spezzarli in piu' commit
            Start-Sleep -Seconds 4
            $status2 = (git status --porcelain 2>$null) -join "`n"

            if ($status1 -eq $status2 -and $status2) {
                git add -A 2>$null | Out-Null
                $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                git commit -m "Auto-publish $stamp" 2>$null | Out-Null

                $pushOut = git push origin main 2>&1
                $pushOk = ($LASTEXITCODE -eq 0)

                $filesChanged = ($status2 -split "`n" | Where-Object { $_ -ne "" }).Count
                if ($pushOk) {
                    Write-Log "Pubblicato ($filesChanged file modificati)"
                } else {
                    Write-Log "ERRORE push: $pushOut"
                }
            }
        }
    } catch {
        Write-Log "ERRORE: $($_.Exception.Message)"
    }

    # "battito cardiaco": un file con l'ora di adesso, riscritto ad ogni giro.
    # Se questo processo muore (il PC va in sospensione, si riavvia, ecc.) il
    # file smette di aggiornarsi — è cosi' che un'altra attivita' pianificata
    # (vedi setup-autopublish.ps1) puo' accorgersi che serve un riavvio.
    try { Set-Content -Path $heartbeatPath -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -Encoding UTF8 } catch {}

    Start-Sleep -Seconds 8
}
