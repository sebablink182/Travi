// Screenshot di una pagina di anteprima a misura iPhone.
//   node _tools/scatta.js _prev-home.html /tmp/home.png [scrollY]
// Serve playwright + un Chromium (nel container di lavoro: /opt/pw-browsers/chromium).
const path = require('path');
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 393, height: 852 }, deviceScaleFactor: 2 });
  await p.goto('file://' + path.resolve(process.argv[2]));
  await p.waitForTimeout(700);
  const y = parseInt(process.argv[4] || '0', 10);
  if (y) {
    await p.evaluate((v) => { const s = document.querySelector('.view.active .scroll'); if (s) s.scrollTop = v; }, y);
    await p.waitForTimeout(400);
  }
  await p.screenshot({ path: process.argv[3] });
  await b.close();
})();
