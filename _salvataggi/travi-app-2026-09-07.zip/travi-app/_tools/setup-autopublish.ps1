﻿# Travi - installazione automatica (da lanciare UNA SOLA VOLTA)
# Registra un'attivita' pianificata di Windows che avvia auto-publish.ps1 ad
# ogni accensione/accesso al PC, in background, senza finestre visibili.
# Dopo aver lanciato questo script una volta, non serve mai piu' aprire
# PowerShell per pubblicare le modifiche a Travi.

$ErrorActionPreference = "Stop"

$taskName   = "TraviAutoPublish"
$scriptPath = Join-Path $PSScriptRoot "auto-publish.ps1"

if (-not (Test-Path $scriptPath)) {
    Write-Host "ERRORE: non trovo auto-publish.ps1 accanto a questo script ($scriptPath)" -ForegroundColor Red
    exit 1
}

Write-Host "Cartella script: $PSScriptRoot"
Write-Host "Registro l'attivita' pianificata '$taskName'..."

# Se esiste gia' (es. secondo lancio di questo setup), la rimuovo e la ricreo pulita
$existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($existing) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Write-Host "Rimossa una registrazione precedente."
}

$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$scriptPath`""

# Due trigger:
# 1) all'accensione/accesso, come prima.
# 2) un controllo ogni 5 minuti per sempre: se il processo e' gia' vivo, con
#    "MultipleInstances IgnoreNew" qui sotto questo tentativo viene
#    semplicemente ignorato (nessun doppione); se invece e' morto per
#    qualunque motivo (PC riavviato, sospensione, chiuso per sbaglio...), lo
#    fa ripartire da solo entro 5 minuti invece di restare fermo per sempre.
$triggerLogon  = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERNAME"
$triggerRepeat = New-ScheduledTaskTrigger -Once -At (Get-Date) `
    -RepetitionInterval (New-TimeSpan -Minutes 5) `
    -RepetitionDuration (New-TimeSpan -Days 3650)

$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1)

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($triggerLogon, $triggerRepeat) -Settings $settings -RunLevel Limited | Out-Null

Write-Host "Registrata. La avvio subito, cosi' parte gia' da ora senza aspettare il prossimo riavvio..."
Start-ScheduledTask -TaskName $taskName

Start-Sleep -Seconds 3
$info = Get-ScheduledTask -TaskName $taskName | Get-ScheduledTaskInfo
Write-Host ""
Write-Host "Fatto. Stato attivita': $($info.LastTaskResult) (0 = ok)"
Write-Host "Da ora in poi, ogni volta che Claude scrive dei file in Desktop\travi-app,"
Write-Host "vengono pubblicati da soli su GitHub entro ~15-20 secondi."
Write-Host "Si controlla anche da solo ogni 5 minuti: se per qualunque motivo si ferma"
Write-Host "(PC riavviato, sospensione...), riparte da solo entro 5 minuti."
Write-Host "Log: $env:USERPROFILE\Desktop\travi-app\_tools\autopublish.log"
Write-Host ""
Write-Host "Per disattivarlo in futuro, in PowerShell:"
Write-Host "  Unregister-ScheduledTask -TaskName TraviAutoPublish -Confirm:`$false"
