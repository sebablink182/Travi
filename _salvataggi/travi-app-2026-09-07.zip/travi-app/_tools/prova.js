/*
 * Travi — prova automatica dell'app intera.
 *
 * Apre l'app vera in un browser headless e ci si comporta come un dito:
 * cambia pagina, apre fogli, trascina, salva, spegne la rete. Serve a non
 * dover riprovare a mano venti cose ogni volta che si tocca qualcosa — e a
 * scoprire le rotture PRIMA che finiscano sul telefono.
 *
 * Firebase è sostituito da finzioni locali (l'app vera sta dietro il login e
 * i dati del viaggio non sono pubblicati): il codice provato è quello vero,
 * riga per riga, tranne le tre import di Firebase.
 *
 * Uso:  node _tools/prova.js
 * Serve: playwright + un Chromium (nel container: /opt/pw-browsers/chromium).
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { chromium } = require(process.env.PW || '/home/claude/.npm-global/lib/node_modules/playwright');

const RADICE = path.resolve(__dirname, '..');
const PORTA = 8901;

/* ---------- dati finti: un mini-viaggio, non quello vero ---------- */
const FINTI = {
  trip: { start: '2027-05-05', end: '2027-05-07' },
  days: [
    { id: 'g1', date: '2027-05-05', city: 'Tokyo', theme: 'Arrivo' },
    { id: 'g2', date: '2027-05-06', city: 'Tokyo', theme: 'Asakusa' },
    { id: 'g3', date: '2027-05-07', city: 'Kyoto', theme: 'Templi' },
  ],
  stops: [
    { id: 's1', day: 'g1', time: '10:00', title: 'Senso-ji', sub: 'Asakusa, Tokyo', cat: 'temple', dur: 60, tmin: 0, tmode: 'walk', lat: 35.7148, lon: 139.7967 },
    { id: 's2', day: 'g1', time: '12:00', title: 'Nakamise-dori', sub: 'Asakusa, Tokyo', cat: 'shopping', dur: 45, tmin: 5, tmode: 'walk', lat: 35.7112, lon: 139.7966 },
    { id: 's3', day: 'g1', time: '15:00', title: 'Tokyo Skytree', sub: 'Sumida, Tokyo', cat: 'view', dur: 90, tmin: 20, tmode: 'metro', lat: 35.7101, lon: 139.8107 },
    { id: 's4', day: 'g2', time: '09:30', title: 'Meiji Jingu', sub: 'Shibuya, Tokyo', cat: 'temple', dur: 75, tmin: 0, tmode: 'walk', lat: 35.6764, lon: 139.6993 },
  ],
};

/* ---------- banco di prova: l'app vera con Firebase finto ---------- */
function preparaBanco() {
  const app = fs.readFileSync(path.join(RADICE, 'js/app.js'), 'utf8');
  const stub = `// FILE DI PROVA generato da _tools/prova.js — si cancella da solo.
const auth = {}, db = {};
const onAuthStateChanged = (a, cb) => cb({ uid: 'prova' });
const signInWithEmailAndPassword = () => Promise.resolve();
const signOut = () => { window.__uscito = true; };
const doc = () => ({});
const getDoc = () => Promise.resolve({ exists: () => true, data: () => (${JSON.stringify(FINTI)}) });
const setDoc = (r, payload) => { window.__salvato = payload; return Promise.resolve(); };
const onSnapshot = (r, cb) => { cb({ exists: () => false }); return () => {}; };

`;
  fs.writeFileSync(path.join(RADICE, '_test-app.mjs'), stub + app.slice(app.indexOf('(function () {')));

  let html = fs.readFileSync(path.join(RADICE, 'index.html'), 'utf8');
  html = html.replace('<script type="module" src="js/app.js"></script>', '<script type="module" src="_test-app.mjs"></script>');
  fs.writeFileSync(path.join(RADICE, '_test.html'), html);
}
function pulisciBanco() {
  ['_test-app.mjs', '_test.html'].forEach((f) => { try { fs.unlinkSync(path.join(RADICE, f)); } catch (e) {} });
}

/* ---------- server locale ---------- */
const TIPI = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.jpg': 'image/jpeg', '.png': 'image/png' };
function avviaServer() {
  return http.createServer((req, res) => {
    const f = path.join(RADICE, decodeURIComponent(req.url.split('?')[0]));
    fs.readFile(f, (err, d) => {
      if (err) { res.writeHead(404); res.end(); return; }
      res.writeHead(200, { 'Content-Type': TIPI[path.extname(f)] || 'application/octet-stream' });
      res.end(d);
    });
  }).listen(PORTA);
}

/* ---------- esito ---------- */
const esiti = [];
function verifica(nome, ok, dettaglio) {
  esiti.push({ nome, ok: !!ok, dettaglio: dettaglio || '' });
  console.log((ok ? '  OK   ' : '  ROTTO') + '  ' + nome + (dettaglio ? '   → ' + dettaglio : ''));
}

(async () => {
  preparaBanco();
  const server = avviaServer();
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await browser.newContext({
    viewport: { width: 393, height: 852 }, hasTouch: true, isMobile: true,
    serviceWorkers: 'allow',
    permissions: ['geolocation'],
    geolocation: { latitude: 35.7100, longitude: 139.7950 }, // ~500 m da Senso-ji
  });
  const p = await ctx.newPage();
  const errori = [];
  p.on('pageerror', (e) => errori.push(String(e).split('\n')[0]));
  p.on('console', (m) => { if (m.type() === 'error' && !/favicon|Failed to load resource/.test(m.text())) errori.push('console: ' + m.text().slice(0, 120)); });

  await p.goto(`http://localhost:${PORTA}/_test.html`, { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(2500);

  console.log('\n— AVVIO —');
  verifica('l\'app parte e mostra il contenuto', await p.evaluate(() => !document.getElementById('app-root').hidden));
  verifica('nessun errore JavaScript all\'avvio', errori.length === 0, errori.slice(0, 3).join(' | '));
  verifica('la Home ha i dati del giorno', await p.evaluate(() => !!document.getElementById('hero-city').textContent.trim()));

  console.log('\n— NAVIGAZIONE (5 pagine) —');
  for (const [vista, etichetta] of [['itinerario', 'Itinerario'], ['mappa', 'Mappa'], ['preferiti', 'Preferiti'], ['altro', 'Altro'], ['home', 'Home']]) {
    const ok = await p.evaluate((v) => {
      document.querySelector(`.tab[data-view="${v}"]`).click();
      return document.getElementById('view-' + v).classList.contains('active');
    }, vista);
    verifica(`si apre ${etichetta}`, ok);
  }

  console.log('\n— ITINERARIO —');
  await p.evaluate(() => document.querySelector('.tab[data-view="itinerario"]').click());
  await p.waitForTimeout(400);
  const tappe = await p.evaluate(() => document.querySelectorAll('.stopcard').length);
  verifica('le tappe del giorno sono in lista', tappe === 3, tappe + ' tappe');
  const fatta = await p.evaluate(() => {
    document.querySelector('.stopcard .quickdone').click();
    return document.querySelector('.stopcard').classList.contains('done');
  });
  verifica('il tasto ✓ segna la tappa come fatta', fatta);
  await p.evaluate(() => document.querySelector('.stopcard .quickdone').click());

  console.log('\n— DOVE SONO ADESSO —');
  // In un giorno che non è oggi il pannello della giornata parte chiuso: si
  // apre con "Prova questa giornata a un altro orario". È la strada che fa
  // anche un dito vero, ed è l'unica praticabile finché il viaggio è lontano.
  await p.evaluate(() => { const a = document.getElementById('prova-apri'); if (a) a.click(); });
  await p.waitForTimeout(300);
  await p.evaluate(() => { const b = document.getElementById('gps-on'); if (b) b.click(); });
  await p.waitForTimeout(1500);
  const gps = await p.evaluate(() => {
    const r = document.querySelector('.qui-riga');
    return r ? r.textContent.replace(/\s+/g, ' ').trim() : null;
  });
  verifica('la posizione entra nel calcolo della giornata', !!gps, gps || 'riga assente');

  console.log('\n— FOGLIO DELLA TAPPA —');
  await p.evaluate(() => document.querySelector('.stopcard').click());
  await p.waitForTimeout(500);
  const foglio = await p.evaluate(() => {
    const s = document.getElementById('sheet'), b = s.querySelector('.sheet-body');
    return {
      aperto: s.classList.contains('show'),
      scorreDiLato: b.scrollWidth > b.clientWidth + 1,
      deveScorrere: b.scrollHeight > b.clientHeight + 1,
      salvaVisibile: !!s.querySelector('.sheet-footer #btn-save'),
      fotoInTesta: !document.getElementById('sheet-hero').hidden,
    };
  });
  verifica('si apre toccando la tappa', foglio.aperto);
  verifica('non si trascina di lato', !foglio.scorreDiLato);
  verifica('ci sta senza scorrere', !foglio.deveScorrere);
  verifica('Elimina/Salva sempre visibili', foglio.salvaVisibile);
  verifica('la foto della tappa è in testa', foglio.fotoInTesta);

  const bloccoSotto = await p.evaluate(() => {
    const sotto = document.querySelector('#view-itinerario .scroll');
    const t = new Touch({ identifier: 3, target: sotto, clientX: 200, clientY: 400 });
    const ev = new TouchEvent('touchmove', { bubbles: true, cancelable: true, touches: [t], targetTouches: [t], changedTouches: [t] });
    sotto.dispatchEvent(ev);
    return ev.defaultPrevented;
  });
  verifica('con il foglio aperto la pagina sotto non scorre', bloccoSotto);

  const trascinato = await p.evaluate(() => {
    const s = document.getElementById('sheet');
    const r = s.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + 30;
    const tocco = (tipo, cy) => {
      const t = new Touch({ identifier: 1, target: s, clientX: x, clientY: cy });
      s.dispatchEvent(new TouchEvent(tipo, { bubbles: true, cancelable: true, touches: tipo === 'touchend' ? [] : [t], targetTouches: tipo === 'touchend' ? [] : [t], changedTouches: [t] }));
    };
    tocco('touchstart', y);
    let seguito = false;
    for (let d = 30; d <= 210; d += 30) { tocco('touchmove', y + d); if (getComputedStyle(s).transform.includes(String(d))) seguito = true; }
    tocco('touchend', y + 210);
    return { seguito, chiuso: !s.classList.contains('show') };
  });
  verifica('il foglio segue il dito', trascinato.seguito);
  verifica('trascinandolo giù si chiude', trascinato.chiuso);

  console.log('\n— PREFERITI —');
  await p.evaluate(() => document.querySelector('.tab[data-view="preferiti"]').click());
  await p.waitForTimeout(300);
  const prefAgg = await p.evaluate(() => {
    document.getElementById('btn-add-fav').click();
    document.getElementById('fav-title').value = 'Nishiki Market';
    document.getElementById('fav-sub').value = 'Nakagyo, Kyoto';
    document.getElementById('fav-save').click();
    return document.querySelectorAll('.fav-card').length;
  });
  await p.waitForTimeout(300);
  verifica('un preferito si salva e compare in lista', prefAgg === 1, prefAgg + ' schede');
  const gruppo = await p.evaluate(() => (document.querySelector('.fav-city-heading') || {}).textContent);
  verifica('è raggruppato per città', gruppo === 'Kyoto', 'gruppo: ' + gruppo);
  const pianifica = await p.evaluate(() => {
    document.querySelector('.fav-plan').click();
    return { aperto: document.getElementById('assign-sheet').classList.contains('show'), opzioni: document.querySelectorAll('.assign-opt').length };
  });
  verifica('"Pianifica" apre le opzioni verificate dal motore', pianifica.aperto, pianifica.opzioni + ' giorni proposti');
  await p.evaluate(() => document.getElementById('assign-close').click());

  console.log('\n— PRENOTAZIONI —');
  await p.evaluate(() => document.querySelector('.tab[data-view="altro"]').click());
  await p.waitForTimeout(300);
  const pren = await p.evaluate(() => {
    document.getElementById('btn-add-pren').click();
    document.getElementById('pren-nome').value = 'Volo AZ0792 Roma → Tokyo';
    document.getElementById('pren-codice').value = 'XK4T9P';
    document.getElementById('pren-data').value = '2027-05-05';
    document.getElementById('pren-ora').value = '14:55';
    document.getElementById('pren-salva').click();
    return {
      schede: document.querySelectorAll('.pren-card').length,
      codice: (document.querySelector('.pren-codice') || {}).textContent,
      quando: (document.querySelector('.pren-quando') || {}).textContent,
    };
  });
  await p.waitForTimeout(300);
  verifica('una prenotazione si salva e compare', pren.schede === 1, pren.schede + ' schede');
  verifica('il codice è in evidenza', (pren.codice || '').includes('XK4T9P'), pren.codice);
  verifica('la data è leggibile', (pren.quando || '').includes('14:55'), pren.quando);
  const salvato = await p.evaluate(() => {
    const s = window.__salvato || {};
    const contieneUndefined = JSON.stringify(s) !== JSON.stringify(JSON.parse(JSON.stringify(s)));
    return { chiavi: Object.keys(s), prenotazioni: (s.bookings || []).length, contieneUndefined };
  });
  verifica('il salvataggio contiene le prenotazioni', salvato.prenotazioni === 1, 'chiavi: ' + salvato.chiavi.join(', '));
  verifica('nessun campo undefined verso Firestore', !salvato.contieneUndefined);

  console.log('\n— IDEE PER CITTÀ —');
  // Il giro completo che conta: idea → preferito → pianificabile. Se questo
  // si rompe, "Esplora" diventa una lista di lettura e basta.
  await p.evaluate(() => document.querySelector('.tab[data-view="preferiti"]').click());
  await p.waitForTimeout(300);
  const idee = await p.evaluate(async () => {
    document.getElementById('btn-idee').click();
    await new Promise((r) => setTimeout(r, 400));
    const citta = [...document.querySelectorAll('#idee-citta .pick')].map((e) => e.textContent);
    const attiva = (document.querySelector('#idee-citta .pick.sel') || {}).textContent;
    const schede = document.querySelectorAll('#idee-lista .idea').length;
    const prima = document.querySelector('#idee-lista .idea');
    const titolo = prima.querySelector('.i-t').textContent;
    prima.querySelector('.idea-salva').click();
    await new Promise((r) => setTimeout(r, 500));
    const fav = ((window.__salvato || {}).favorites || []).find((f) => f.title === titolo);
    return {
      aperto: document.getElementById('idee-sheet').classList.contains('show'),
      citta, attiva, schede, titolo,
      segnata: document.querySelector('#idee-lista .idea').classList.contains('gia'),
      conPosizione: !!(fav && fav.lat && fav.lon),
      note: (fav || {}).notes || '',
    };
  });
  verifica('le idee si aprono dai Preferiti', idee.aperto);
  verifica('ci sono le città del viaggio', idee.citta.length >= 5, idee.citta.join(', '));
  verifica('parte dalla città di oggi', !!idee.attiva, idee.attiva);
  verifica('la città mostra le sue idee', idee.schede >= 4, idee.schede + ' idee');
  verifica('un\'idea diventa un preferito', !!idee.conPosizione, idee.titolo);
  verifica('e si porta dietro la posizione (quindi il pin sulla mappa)', idee.conPosizione);
  verifica('e il perché finisce nelle note', idee.note.length > 20);
  verifica('l\'idea già salvata resta segnata', idee.segnata);
  const pianificabile = await p.evaluate(async () => {
    document.getElementById('idee-close').click();
    await new Promise((r) => setTimeout(r, 400));
    const card = [...document.querySelectorAll('.fav-card')].pop();
    card.querySelector('.fav-plan').click();
    await new Promise((r) => setTimeout(r, 300));
    const n = document.querySelectorAll('.assign-opt').length;
    document.getElementById('assign-close').click();
    return n;
  });
  verifica('e da lì si pianifica come ogni altro preferito', pianificabile > 0, pianificabile + ' giorni proposti');
  await p.evaluate(() => document.querySelector('.tab[data-view="altro"]').click());
  await p.waitForTimeout(300);

  console.log('\n— FRASI IN GIAPPONESE —');
  const frasi = await p.evaluate(() => {
    document.getElementById('riga-frasi').click();
    const n = document.querySelectorAll('#frasi-lista .frase').length;
    const inp = document.getElementById('frasi-cerca');
    inp.value = 'conto'; inp.dispatchEvent(new Event('input'));
    const filtrate = [...document.querySelectorAll('#frasi-lista .frase .f-it')].map((e) => e.textContent);
    inp.value = ''; inp.dispatchEvent(new Event('input'));
    const prima = document.querySelector('#frasi-lista .frase');
    return {
      aperto: document.getElementById('frasi-sheet').classList.contains('show'),
      n, filtrate,
      tre: !!(prima.querySelector('.f-ja') && prima.querySelector('.f-ro') && prima.querySelector('.f-it')),
      corpoJa: getComputedStyle(prima.querySelector('.f-ja')).fontSize,
    };
  });
  verifica('il frasario si apre', frasi.aperto);
  verifica('ci sono abbastanza frasi', frasi.n >= 50, frasi.n + ' frasi');
  verifica('ogni frase ha giapponese, lettura e italiano', frasi.tre);
  verifica('il giapponese è grande da mostrare', parseFloat(frasi.corpoJa) >= 18, frasi.corpoJa);
  verifica('la ricerca dentro il frasario filtra', frasi.filtrate.length > 0 && frasi.filtrate.length < frasi.n, frasi.filtrate[0]);
  await p.evaluate(() => document.getElementById('frasi-close').click());
  await p.waitForTimeout(250);

  console.log('\n— YEN ED EURO —');
  const cambio = await p.evaluate(async () => {
    document.getElementById('riga-cambio').click();
    await new Promise((r) => setTimeout(r, 400));
    const jpy = document.getElementById('cambio-jpy');
    const eur = document.getElementById('cambio-eur');
    jpy.value = '10.000'; jpy.dispatchEvent(new Event('input'));
    const versoEuro = eur.value;
    eur.value = '50'; eur.dispatchEvent(new Event('input'));
    const versoYen = jpy.value;
    return {
      aperto: document.getElementById('cambio-sheet').classList.contains('show'),
      versoEuro, versoYen,
      scala: document.querySelectorAll('.cambio-scala-riga').length,
      nota: document.getElementById('cambio-nota').textContent,
    };
  });
  const euroCalcolati = parseFloat((cambio.versoEuro || '').replace('.', '').replace(',', '.'));
  const yenCalcolati = parseFloat((cambio.versoYen || '').replace(/\./g, ''));
  verifica('il convertitore si apre', cambio.aperto);
  verifica('10.000 ¥ danno una cifra sensata in euro', euroCalcolati > 40 && euroCalcolati < 80, cambio.versoEuro + ' €');
  verifica('e funziona anche al contrario', yenCalcolati > 6000 && yenCalcolati < 12000, cambio.versoYen + ' ¥');
  verifica('la scala a colpo d\'occhio è piena', cambio.scala === 6);
  verifica('dice di quando è il cambio', /aggiornato il \d{2}\/\d{2}\/\d{4}/.test(cambio.nota), cambio.nota);
  await p.evaluate(() => document.getElementById('cambio-close').click());
  await p.waitForTimeout(250);

  console.log('\n— DIARIO —');
  const diario = await p.evaluate(async () => {
    document.getElementById('riga-diario').click();
    await new Promise((r) => setTimeout(r, 300));
    const righe = document.querySelectorAll('#diario-body .dia-giorno');
    // apriDiario apre da solo il giorno di oggi: si prende una riga CHIUSA,
    // così il tocco che segue è davvero un'apertura e non una chiusura.
    const prima = [...righe].find((r) => !r.classList.contains('aperto')) || righe[0];
    const indice = [...righe].indexOf(prima);
    prima.querySelector('.dia-testa').click();
    const ta = prima.querySelector('textarea');
    ta.value = 'Partiti da Fiumicino con due valigie e zero sonno.';
    ta.dispatchEvent(new Event('input'));
    prima.querySelectorAll('.dia-voti .pick')[1].click();
    await new Promise((r) => setTimeout(r, 900));
    return {
      giorni: righe.length,
      aperta: prima.classList.contains('aperto'),
      anteprima: prima.querySelector('.dia-s').textContent,
      soli: [...document.querySelectorAll('#diario-body .dia-giorno.aperto')].length,
      voto: ((window.__salvato || {}).diario || {})['g' + (indice + 1)] ? ((window.__salvato || {}).diario || {})['g' + (indice + 1)].v : null,
      testoSalvato: ((window.__salvato || {}).diario || {})['g' + (indice + 1)] ? ((window.__salvato || {}).diario || {})['g' + (indice + 1)].t : null,
      sottotitolo: document.getElementById('rm-diario-sub').textContent,
    };
  });
  verifica('il diario ha una riga per ogni giorno del viaggio', diario.giorni === 3, diario.giorni + ' giorni');
  verifica('si apre solo il giorno toccato', diario.aperta && diario.soli === 1);
  verifica('quello che si scrive finisce nel salvataggio', (diario.testoSalvato || '').includes('Fiumicino'), diario.testoSalvato);
  verifica('il voto della giornata si salva', diario.voto === 'bellissima', diario.voto);
  verifica('si salva da solo, senza tasto Salva', (diario.anteprima || '').includes('Fiumicino'));
  verifica('la riga in Altro conta le giornate scritte', /giornat/.test(diario.sottotitolo), diario.sottotitolo);
  await p.evaluate(() => document.getElementById('diario-close').click());
  await p.waitForTimeout(250);

  console.log('\n— RICERCA —');
  // La lente cerca in una volta sola fra tappe, preferiti e prenotazioni: qui
  // si controlla che trovi in tutte e tre le casse, non solo nella prima.
  const ric = await p.evaluate(async () => {
    document.querySelector('.cerca-apri').click();
    const inp = document.getElementById('cerca-tutto');
    const scrivi = (t) => { inp.value = t; inp.dispatchEvent(new Event('input')); };
    const conta = () => document.querySelectorAll('#cerca-esiti .cerca-esito').length;
    scrivi('a');
    const troppoCorto = conta();
    scrivi('senso');
    const tappa = { n: conta(), t: (document.querySelector('.ce-t') || {}).textContent };
    scrivi('XK4T9P');
    const codice = { n: conta(), t: (document.querySelector('.ce-t') || {}).textContent };
    scrivi('zzzqqq');
    const vuoto = !!document.querySelector('.cerca-vuoto');
    return { aperto: document.getElementById('cerca-sheet').classList.contains('show'), troppoCorto, tappa, codice, vuoto };
  });
  verifica('la lente apre il foglio di ricerca', ric.aperto);
  verifica('una lettera sola non cerca ancora', ric.troppoCorto === 0);
  verifica('trova una tappa per nome', ric.tappa.n > 0, ric.tappa.t);
  verifica('trova una prenotazione dal codice', ric.codice.n > 0, ric.codice.t);
  verifica('dice chiaramente quando non trova nulla', ric.vuoto);
  const salto = await p.evaluate(async () => {
    const inp = document.getElementById('cerca-tutto');
    inp.value = 'senso'; inp.dispatchEvent(new Event('input'));
    document.querySelector('#cerca-esiti .cerca-esito').click();
    await new Promise((r) => setTimeout(r, 500));
    return {
      chiuso: !document.getElementById('cerca-sheet').classList.contains('show'),
      vista: (document.querySelector('.view.active') || {}).id,
      foglio: document.getElementById('sheet').classList.contains('show'),
    };
  });
  verifica('toccare un risultato porta al giorno giusto', salto.vista === 'view-itinerario', salto.vista);
  verifica('e apre la tappa trovata', salto.foglio && salto.chiuso);
  await p.evaluate(() => document.getElementById('sheet-close').click());
  await p.waitForTimeout(300);

  console.log('\n— SENZA RETE —');
  // Il service worker mette in cache i file veri (index.html, js/app.js): qui
  // gira il banco di prova, quindi si aggiungono a mano i suoi due file — è
  // esattamente ciò che sul telefono succede da solo con quelli veri.
  await p.reload({ waitUntil: 'domcontentloaded', timeout: 15000 }).catch(() => {});
  await p.waitForFunction(() => !!navigator.serviceWorker.controller, null, { timeout: 10000 }).catch(() => {});
  await p.evaluate(async () => {
    const nomi = await caches.keys();
    const c = await caches.open(nomi[0]);
    await c.addAll(['_test.html', '_test-app.mjs']).catch(() => {});
  });
  await p.waitForTimeout(600);
  await ctx.setOffline(true);
  let riaperta = true;
  try { await p.goto(`http://localhost:${PORTA}/_test.html`, { waitUntil: 'domcontentloaded', timeout: 15000 }); }
  catch (e) { riaperta = false; }
  await p.waitForTimeout(1500);
  const offline = await p.evaluate(() => ({
    titolo: document.title,
    stile: getComputedStyle(document.body).fontSize,
    pillola: !!document.querySelector('.tabbar-inner'),
    avviso: !document.getElementById('offline-pill').hidden,
  })).catch(() => ({}));
  verifica('l\'app si riapre senza rete', riaperta && offline.titolo === 'Travi');
  verifica('lo stile è servito dalla cache', offline.stile === '17px', offline.stile);
  verifica('compare l\'avviso "Senza rete"', offline.avviso);

  await browser.close();
  server.close();
  pulisciBanco();

  const rotti = esiti.filter((e) => !e.ok);
  console.log('\n' + '='.repeat(52));
  console.log(rotti.length === 0
    ? `TUTTO A POSTO — ${esiti.length} verifiche superate`
    : `${rotti.length} SU ${esiti.length} DA SISTEMARE:\n  ` + rotti.map((r) => r.nome).join('\n  '));
  process.exit(rotti.length === 0 ? 0 : 1);
})();
