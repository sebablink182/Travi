import { auth, db } from "./firebase-init.js";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import {
  doc,
  getDoc,
  setDoc,
  onSnapshot,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";

(function () {
  "use strict";

  /* ---------- categorie & trasporti (generici, non sensibili) ---------- */
  var CATS = [
    { id: "temple", label: "Tempio", icon: "ic-temple" },
    { id: "nature", label: "Natura", icon: "ic-leaf" },
    { id: "food", label: "Cibo", icon: "ic-bowl" },
    { id: "shopping", label: "Shopping", icon: "ic-bag" },
    { id: "view", label: "Panorama", icon: "ic-view" },
    { id: "experience", label: "Esperienza", icon: "ic-star" },
    { id: "transfer", label: "Trasferimento", icon: "ic-train" },
    { id: "hotel", label: "Hotel", icon: "ic-bed" },
  ];
  // Priorità: quanto ci tenete. Vedi js/giornata.js per come pesa nei consigli.
  var PRIORITA = [
    { id: "top",   label: "Imperdibile", icon: "ic-star" },
    { id: "norm",  label: "Normale",     icon: "ic-dot" },
    { id: "extra", label: "Se avanza",   icon: "ic-dash" },
  ];
  // Durata come scelta rapida invece di un numero da digitare: raramente si
  // sa in anticipo quanto ci si fermerà davvero da qualche parte.
  var DURATA_OPTS = [
    { id: "15", label: "15 min" }, { id: "30", label: "30" }, { id: "45", label: "45" },
    { id: "60", label: "1 h" }, { id: "90", label: "1½ h" }, { id: "120", label: "2 h+" }
  ];
  // Tipi di prenotazione: quello che davvero si prenota in un viaggio così.
  var PREN_TIPI = [
    { id: "volo",  label: "Volo",       icon: "ic-plane" },
    { id: "hotel", label: "Hotel",      icon: "ic-bed" },
    { id: "treno", label: "Treno",      icon: "ic-train" },
    { id: "attivita", label: "Attività", icon: "ic-star" },
    { id: "altro", label: "Altro",      icon: "ic-doc" },
  ];
  var TRANSPORTS = [
    { id: "walk", label: "A piedi", icon: "ic-walk" },
    { id: "metro", label: "Metro/Treno", icon: "ic-train" },
    { id: "bus", label: "Bus", icon: "ic-bus" },
    { id: "car", label: "Taxi/Auto", icon: "ic-car" },
  ];
  function cat(id) {
    return CATS.find(function (c) { return c.id === id; }) || CATS[5];
  }
  function transp(id) {
    return TRANSPORTS.find(function (t) { return t.id === id; }) || TRANSPORTS[0];
  }

  /* ---------- dati del viaggio: caricati da Firestore, non hardcoded ---------- */
  var TRIP = { start: "2027-05-05", end: "2027-05-18" };
  var DAYS = [];
  var SEED_STOPS = [];
  var dataLoaded = false;

  var state = { overrides: {}, custom: [], removed: [], budget: [], favorites: [], bookings: [], diario: {} };
  var BUDGET_WHO = [
    { id: "sebastian", label: "Sebastian" },
    { id: "alessandra", label: "Alessandra" },
    { id: "insieme", label: "Insieme" },
  ];
  /* ---------- coordinate approssimative delle città in itinerario (per meteo live) ---------- */
  var CITY_COORDS = {
    "Tokyo": { lat: 35.6762, lon: 139.6503 },
    "Hakone": { lat: 35.2324, lon: 139.1069 },
    "Kanazawa": { lat: 36.5613, lon: 136.6562 },
    "Kyoto": { lat: 35.0116, lon: 135.7681 },
    "Hiroshima": { lat: 34.3853, lon: 132.4553 },
    "Miyajima": { lat: 34.2969, lon: 132.3196 },
    "Osaka": { lat: 34.6937, lon: 135.5023 },
  };
  function cityKeyFor(cityStr) {
    var keys = Object.keys(CITY_COORDS);
    for (var i = 0; i < keys.length; i++) {
      if (cityStr && cityStr.indexOf(keys[i]) !== -1) return keys[i];
    }
    return "Tokyo";
  }
  // Stessa idea di cityKeyFor, ma per raggruppare i Preferiti: qui un posto
  // che non nomina nessuna delle città del viaggio deve finire in "Altro",
  // non silenziosamente sotto Tokyo (che è il fallback giusto per il meteo,
  // ma sbagliato per un raggruppamento).
  function cityKeyForFav(text) {
    var keys = Object.keys(CITY_COORDS);
    for (var i = 0; i < keys.length; i++) {
      if (text && text.indexOf(keys[i]) !== -1) return keys[i];
    }
    return "Altro";
  }
  var selectedDay = { itinerario: null };
  var editingId = null;
  var unsubState = null;

  /* ---------- auth gate ---------- */
  var loginGate = document.getElementById("login-gate");
  var appRoot = document.getElementById("app-root");
  var loginForm = document.getElementById("login-form");
  var loginError = document.getElementById("login-error");
  var loginSubmit = document.getElementById("login-submit");
  // L'uscita dall'account vive nel tab Altro (una riga con il suo tasto).
  // Prima era un gesto nascosto sul logo: tolto quando Altro le ha dato un
  // posto vero e visibile.
  function esciDavvero() {
    if (unsubState) { unsubState(); unsubState = null; }
    signOut(auth);
  }

  onAuthStateChanged(auth, function (user) {
    if (user) {
      loginGate.hidden = true;
      appRoot.hidden = false;
      bootApp();
    } else {
      appRoot.hidden = true;
      loginGate.hidden = false;
      loginSubmit.disabled = false;
      loginSubmit.textContent = "Accedi";
    }
  });

  /* ---------- avvio dell'app una volta autenticati ---------- */
  var appBooted = false;
  function bootApp() {
    if (appBooted) return; // evita doppie sottoscrizioni se onAuthStateChanged rifira
    appBooted = true;

    function avvia() {
      dataLoaded = true;
      selectedDay.itinerario = defaultDay();
      loadLocalFallback();
      subscribeState();
      renderAll();
      mostraStatoRete();
      setInterval(renderHome, 60000);
    }

    getDoc(doc(db, "travi", "itinerary")).then(function (snap) {
      if (snap.exists()) {
        var data = snap.data();
        TRIP = data.trip || TRIP;
        DAYS = data.days || [];
        SEED_STOPS = data.stops || [];
        innestaCoordinate();
        salvaItinerarioLocale();
      } else {
        DAYS = [];
        SEED_STOPS = [];
      }
      avvia();
    }).catch(function (err) {
      // Ultima rete di sicurezza: né rete né copia di Firestore, ma la nostra
      // copia dell'itinerario è lì. Meglio partire con dati di ieri che con
      // una schermata d'errore in mezzo a Kyoto.
      if (leggiItinerarioLocale()) { avvia(); return; }
      document.getElementById("view-home").innerHTML =
        '<div style="padding:40px 20px;text-align:center;color:var(--text-muted);line-height:1.5;">' +
        (navigator.onLine
          ? "Non riesco a leggere i dati del viaggio da Firestore.<br>Controllate le Firestore Rules e che l'itinerario sia stato caricato con admin-seed.html."
          : "Siete senza rete e su questo telefono non c'è ancora una copia del viaggio.<br><br>Apritela una volta con la connessione: da lì in poi funzionerà anche senza.") +
        "</div>";
      console.error(err);
    });
  }

  /* ---------- copia locale dell'itinerario ----------
     Firestore ha già una sua copia locale (vedi js/firebase-init.js): questa è
     una seconda rete di sicurezza, indipendente dalla prima. Se IndexedDB non
     fosse disponibile o la copia di Firestore si perdesse, il viaggio resta
     comunque leggibile. Sono pochi kilobyte, e il giorno che serve serve. */
  function salvaItinerarioLocale() {
    try {
      localStorage.setItem("travi-itinerario",
        JSON.stringify({ trip: TRIP, days: DAYS, stops: SEED_STOPS, salvatoIl: Date.now() }));
    } catch (e) {}
  }
  function leggiItinerarioLocale() {
    try {
      var raw = localStorage.getItem("travi-itinerario");
      if (!raw) return false;
      var d = JSON.parse(raw);
      if (!d || !d.days || !d.days.length) return false;
      TRIP = d.trip || TRIP;
      DAYS = d.days;
      SEED_STOPS = d.stops || [];
      innestaCoordinate();
      return true;
    } catch (e) { return false; }
  }

  /* ---------- stato della rete ----------
     Senza rete l'app continua a funzionare sulla copia locale, ma è giusto
     saperlo: quello che si vede potrebbe non essere aggiornatissimo, e le
     modifiche fatte adesso partiranno più tardi. */
  function mostraStatoRete() {
    var pill = document.getElementById("offline-pill");
    if (pill) pill.hidden = navigator.onLine !== false;
  }
  window.addEventListener("offline", mostraStatoRete);
  window.addEventListener("online", function () {
    mostraStatoRete();
    if (dataLoaded) toast("Rete tornata: sincronizzo");
  });

  // L'itinerario su Firestore è stato caricato prima che le coordinate
  // esistessero. Invece di riscriverlo (cancellando le vostre modifiche) le
  // innesto qui all'avvio, e SOLO dove mancano: se un giorno l'itinerario verrà
  // ricaricato con le coordinate dentro, questa funzione non farà più nulla.
  function innestaCoordinate() {
    var C = window.TRAVI_COORDS || {};
    SEED_STOPS.forEach(function (s) {
      if (s.lat == null && C[s.id]) { s.lat = C[s.id][0]; s.lon = C[s.id][1]; }
    });
  }

  function subscribeState() {
    unsubState = onSnapshot(
      doc(db, "travi", "state"),
      function (snap) {
        if (snap.exists()) {
          var data = snap.data();
          state.overrides = data.overrides || {};
          state.custom = data.custom || [];
          state.removed = data.removed || [];
          state.budget = data.budget || [];
          state.favorites = data.favorites || [];
          state.bookings = data.bookings || [];
          state.diario = data.diario || {};
          renderAll();
        }
      },
      function () { /* offline: resta il fallback locale */ }
    );
  }

  function loadLocalFallback() {
    try {
      var raw = localStorage.getItem("travi-state");
      if (raw) {
        var parsed = JSON.parse(raw);
        state.overrides = parsed.overrides || {};
        state.custom = parsed.custom || [];
        state.removed = parsed.removed || [];
        state.budget = parsed.budget || [];
        state.favorites = parsed.favorites || [];
        state.bookings = parsed.bookings || [];
        state.diario = parsed.diario || {};
      }
    } catch (e) {}
  }

  function persist() {
    renderAll();
    var payload = { overrides: state.overrides, custom: state.custom, removed: state.removed, budget: state.budget, favorites: state.favorites, bookings: state.bookings, diario: state.diario, savedAt: Date.now() };
    try { localStorage.setItem("travi-state", JSON.stringify(payload)); } catch (e) {}
    setDoc(doc(db, "travi", "state"), payload).catch(function () {});
  }

  /* ---------- helpers data/ore ---------- */
  function todayISO() {
    var d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  function defaultDay() {
    if (!DAYS.length) return null;
    var t = todayISO();
    var d = DAYS.find(function (x) { return x.date === t; });
    if (d) return d.id;
    if (t < TRIP.start) return DAYS[0].id;
    if (t > TRIP.end) return DAYS[DAYS.length - 1].id;
    return DAYS[0].id;
  }

  function allStops() {
    var merged = SEED_STOPS.concat(state.custom).filter(function (s) { return state.removed.indexOf(s.id) === -1; });
    return merged.map(function (s) {
      var o = state.overrides[s.id];
      return o ? Object.assign({}, s, o) : s;
    });
  }
  function stopsForDay(dayId) {
    return allStops().filter(function (s) { return s.day === dayId; }).sort(function (a, b) { return a.time.localeCompare(b.time); });
  }
  function dayById(id) { return DAYS.find(function (d) { return d.id === id; }); }
  function weekdayShort(dateStr) {
    var wd = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
    var d = new Date(dateStr + "T00:00:00");
    return wd[d.getDay()];
  }
  function dayNum(dateStr) { return parseInt(dateStr.split("-")[2], 10); }
  function timeToMin(t) { var p = t.split(":"); return parseInt(p[0], 10) * 60 + parseInt(p[1], 10); }
  function minToTime(m) { m = ((m % 1440) + 1440) % 1440; var h = Math.floor(m / 60), mm = m % 60; return String(h).padStart(2, "0") + ":" + String(mm).padStart(2, "0"); }

  /* ---------- feedback aptico ----------
     RICERCA FATTA IL 4/09/2026, per non riprovarci a vuoto fra sei mesi:

     1. navigator.vibrate NON esiste su Safari iOS. Mai implementata, nemmeno
        nelle versioni 26.x (caniuse.com/vibration). Su Android sì.
     2. L'unico appiglio è <input type="checkbox" switch> (Safari 17.4+): è un
        controllo di SISTEMA, e iOS suona il suo "tick" quando cambia stato.
     3. Fino a iOS 26.4 lo si poteva far scattare da codice (.click() su una
        label nascosta) — è la strada che avevo provato, e che infatti non ha
        prodotto niente: **Apple l'ha chiusa in iOS 26.5**. Da lì in poi il
        tick parte SOLO se il dito tocca davvero il controllo (evento fidato).

     Conseguenze pratiche per Travi:
     - aptico mentre si SCORRE la fila dei giorni: impossibile. Lo scorrimento
       non è un tocco su un controllo, e la via da codice è chiusa.
     - aptico al TOCCO di un giorno: possibile, ed è quello che c'è qui sotto —
       un interruttore di sistema vero, invisibile, steso sopra la pillola: il
       dito tocca lui, iOS fa il tick, e il nostro click continua a funzionare
       normalmente perché l'evento sale comunque alla pillola.
     VERIFICATO SUL TELEFONO DI SEB (4/09/2026): funziona, sia in Safari sia
     nella PWA installata sulla schermata Home. Era il punto che nessuna fonte
     documentava — ora lo sappiamo.
     Se Apple chiudesse anche questa, o su un iPhone più vecchio, semplicemente
     non si sente niente: nessun errore, nessun comportamento diverso. */
  function stendiInterruttoreAptico(el) {
    var sw = document.createElement("input");
    sw.type = "checkbox";
    sw.setAttribute("switch", "");      // niente appearance:none: deve restare di sistema
    sw.className = "tocco";
    sw.tabIndex = -1;
    sw.setAttribute("aria-hidden", "true");
    el.appendChild(sw);
  }

  /* ---------- rendering ---------- */
  function renderDayRow(containerId, view) {
    var el = document.getElementById(containerId);
    el.innerHTML = "";
    DAYS.forEach(function (d) {
      var pill = document.createElement("div");
      pill.className = "daypill" + (selectedDay[view] === d.id ? " active" : "");
      pill.innerHTML = '<div class="dw">' + weekdayShort(d.date) + '</div><div class="dn num">' + dayNum(d.date) + "</div>";
      stendiInterruttoreAptico(pill);
      pill.addEventListener("click", function () {
        try { if (navigator.vibrate) navigator.vibrate(7); } catch (e) {} // Android
        selectedDay[view] = d.id; renderAll();
      });
      el.appendChild(pill);
    });
  }

  function iconFor(c) { return '<svg><use href="#' + cat(c).icon + '"/></svg>'; }
  function tIconFor(m) { return '<svg><use href="#' + transp(m).icon + '"/></svg>'; }
  // Le 52 tappe originali hanno una foto vera scelta a mano (s.img). Una tappa
  // aggiunta da voi o messa nei Preferiti non ce l'ha: s.foto è quella trovata
  // in automatico su Wikimedia al salvataggio (vedi js/foto.js). Se anche
  // quella manca (posto non trovato, o ricerca ancora in corso), il segnaposto
  // generico è comunque una foto vera dell'app, non un div vuoto.
  function imgFor(s) {
    if (s && s.img) return "assets/img/" + s.img + ".jpg";
    if (s && s.foto) return s.foto;
    return "assets/img/luogo-generico.jpg";
  }

  /* ---------- stato della giornata ----------
     Il pannello compare SOLO nel giorno in cui vi trovate davvero: in un giorno
     futuro dire "sei in ritardo" non vuol dire niente, e in uno passato nemmeno.
     Tutto il calcolo sta in js/giornata.js, qui c'è solo il disegno. */
  var ETICHETTA = { chiusa: "NON CI ARRIVI", incompleta: "TROPPO POCO", stretta: "PER UN PELO" };

  // Simulazione: permette di guardare una giornata a un'ora diversa da adesso.
  // Non è uno strumento da sviluppatore, è una funzione vera — la sera prima
  // serve sapere che se domani si parte alle 10 invece che alle 9 salta l'ultima
  // tappa. Vive qui dentro e non in una pagina a parte perché i dati del viaggio
  // stanno dietro il login e non sono pubblicati (vedi .gitignore).
  var simula = { attiva: false, minuti: 9 * 60 };

  function oraDiAdesso() {
    var o = new Date();
    return o.getHours() * 60 + o.getMinutes();
  }

  /* ---------- dove siete adesso ----------
     È il pezzo per cui l'app è nata: sapere, mentre si cammina, se le cose
     che restano ci stanno ancora — partendo da dove si è davvero e non da
     dove dice il piano. Il telefono dà la posizione solo dietro richiesta
     esplicita (e su iOS solo da un tocco vero e via HTTPS), quindi è un
     interruttore che accendete voi: acceso consuma batteria, e ha senso solo
     nel giorno che state vivendo.
     La posizione non lascia il telefono: serve solo a calcolare la distanza
     dalla prossima tappa, con le coordinate che sono già dentro l'app. */
  var posizione = null, gpsWatch = null;

  function gpsAcceso() { return gpsWatch !== null; }

  function accendiGPS() {
    if (!navigator.geolocation) { toast("Questo telefono non dà la posizione"); return; }
    toast("Cerco la posizione…");
    gpsWatch = navigator.geolocation.watchPosition(
      function (p) {
        posizione = { lat: p.coords.latitude, lon: p.coords.longitude, quando: Date.now() };
        renderAll();
      },
      function (err) {
        spegniGPS();
        toast(err && err.code === 1
          ? "Posizione negata: si riattiva da Impostazioni → Safari"
          : "Non riesco a leggere la posizione");
      },
      { enableHighAccuracy: true, maximumAge: 30000, timeout: 20000 }
    );
  }

  function spegniGPS() {
    if (gpsWatch !== null) navigator.geolocation.clearWatch(gpsWatch);
    gpsWatch = null;
    posizione = null;
    renderAll();
  }

  // Un metro in più o in meno non serve a nessuno: sotto il chilometro si
  // parla in metri arrotondati, sopra in chilometri con un decimale.
  function distanzaLeggibile(km) {
    return km < 1 ? Math.round(km * 1000 / 10) * 10 + " m" : km.toFixed(1) + " km";
  }

  function renderStatoGiornata(dayId, list) {
    var box = document.getElementById("stato-giornata");
    if (!box || !window.Giornata) return;
    var d = dayById(dayId);
    if (!d) { box.innerHTML = ""; return; }

    var oggi = d.date === todayISO();
    if (!oggi && !simula.attiva) {
      box.innerHTML = '<button class="prova-apri" id="prova-apri">Prova questa giornata a un altro orario</button>';
      document.getElementById("prova-apri").onclick = function () {
        simula.attiva = true;
        var prima = list.length ? window.Giornata.min(list[0].time) : 9 * 60;
        simula.minuti = prima != null ? prima : 9 * 60;
        renderStatoGiornata(dayId, list);
      };
      return;
    }

    var minuti = simula.attiva ? simula.minuti : oraDiAdesso();
    // La posizione entra nel conto anche mentre si sta simulando un altro
    // orario: la distanza da dove siete è un fatto vero comunque, e soprattutto
    // è l'unico modo di PROVARE questa funzione prima di partire — il viaggio è
    // fra mesi, e una funzione che non si può provare arriva rotta in Giappone.
    var dove = posizione || null;
    var e = window.Giornata.calcola(list, minuti, window.TRAVI_ORARI, true, dove);

    var html = "";
    if (simula.attiva) {
      html += '<div class="prova-barra">' +
        '<b id="prova-ora">' + window.Giornata.hhmm(minuti) + "</b>" +
        '<input type="range" id="prova-slider" min="300" max="1380" step="5" value="' + minuti + '">' +
        '<button id="prova-chiudi">✕</button></div>';
    }

    if (e.stato === "finita") {
      html += '<div class="stato-g bene"><div class="cap"><div class="titolo">Giornata completata</div></div></div>';
      box.innerHTML = html;
      agganciaProva(dayId, list);
      return;
    }

    var inRitardo = e.ritardo > 15;
    var titolo;
    if (e.stato === "non-iniziata") titolo = "Non ancora cominciata";
    else if (inRitardo) titolo = "In ritardo di " + e.ritardo + " min";
    else if (e.ritardo < -15) titolo = "In anticipo di " + Math.abs(e.ritardo) + " min";
    else titolo = "In orario";

    html += '<div class="stato-g ' + (e.problemi.length ? "tardi" : (inRitardo ? "" : "bene")) + '">' +
      '<div class="cap"><div class="titolo">' + titolo + "</div>" +
      '<div class="fine">fine prevista ' + e.finePrevista + "</div></div>";

    // Dove siete rispetto alla prossima tappa: la riga che risponde alla
    // domanda vera, "da qui quanto ci metto?".
    if (e.daQui) {
      html += '<div class="qui-riga"><svg><use href="#ic-gps"/></svg>' +
        "<div>Siete a <b>" + distanzaLeggibile(e.daQui.km) + "</b> da " + escapeHtml(e.daQui.titolo) +
        (e.daQui.aPiedi ? " · " + e.daQui.minuti + " min a piedi" : " — troppo per andarci a piedi") +
        '</div><button class="qui-off" id="gps-off">spegni</button></div>';
    }

    // Solo le tappe che restano, e solo quelle che meritano una riga: le prime
    // due comunque, più tutte quelle con un problema. Un elenco lungo qui
    // diventerebbe una seconda lista sopra la lista.
    e.previsioni.forEach(function (p, i) {
      if (i > 1 && p.verdetto === "ok") return;
      var eti = ETICHETTA[p.verdetto]
        ? '<div class="esito e-' + p.verdetto + '">' + ETICHETTA[p.verdetto] + "</div>" : "";
      html += '<div class="riga"><div class="ora">' + p.arrivoOra + "</div>" +
              '<div class="che">' + escapeHtml(p.title) +
              (p.chiudeOra ? ' <span style="color:var(--text-muted)">· chiude ' + p.chiudeOra + "</span>" : "") +
              "</div>" + eti + "</div>";
    });

    var ETI_PRIO = { top: "imperdibile", norm: "normale", extra: "se avanza" };
    var sug = e.suggerimento;
    if (sug && sug.tipo === "sacrifica") {
      var salvate = sug.problemiRisolti.map(function (p) {
        return "<b>" + escapeHtml(p.title) + "</b>" +
               (p.prio === "top" ? " (imperdibile)" : "");
      }).join(", ");
      html += '<div class="consiglio">Rinunciando a <b>' + escapeHtml(sug.titolo) + "</b> (" +
              ETI_PRIO[sug.prio] + ", " + sug.durata + " min) arrivate ancora a " + salvate + ".</div>";
    } else if (sug && sug.tipo === "rinuncia") {
      var top = sug.imperdibiliPerse || [];
      html += '<div class="consiglio">' +
        (top.length
          ? "Non c'è più niente da tagliare, e fra quelle che saltano c'è <b>" +
            top.map(function (p) { return escapeHtml(p.title); }).join("</b> e <b>") + "</b>."
          : "Non c'è più niente da tagliare che basti: <b>" +
            sug.perse.map(function (p) { return escapeHtml(p.title); }).join("</b> e <b>") +
            "</b> non ci stanno più.") + "</div>";

      // Travi conosce tutti i giorni: invece di lasciare la decisione a voi in
      // mezzo alla strada, guarda se un altro giorno nella stessa città ha
      // spazio davvero — verificato, non ipotizzato.
      var daSpostare = (top.length ? top : sug.perse)[0];
      var alt = trovaGiorniAlternativi(daSpostare.id, dayId);
      if (alt && alt.length) {
        var a = alt[0];
        html += '<div class="consiglio">Il <b>' + a.date.slice(8) + "/" + a.date.slice(5, 7) +
          "</b> siete ancora a " + escapeHtml(a.city) + " e quel giorno finirebbe alle " +
          a.fineCon + ": c'è spazio per <b>" + escapeHtml(daSpostare.title) + "</b>." +
          '<button class="sposta" data-tappa="' + daSpostare.id + '" data-giorno="' + a.id +
          '" data-dopo="' + (a.dopoDi ? escapeHtml(a.dopoDi) : "") + '">Sposta lì</button></div>';
      }
    }

    if (!gpsAcceso()) {
      html += '<button class="prova-apri dentro gps" id="gps-on"><svg><use href="#ic-gps"/></svg>Dove sono adesso</button>';
    }
    if (!simula.attiva) {
      html += '<button class="prova-apri dentro" id="prova-apri">Prova a un altro orario</button>';
    }
    box.innerHTML = html + "</div>";
    agganciaProva(dayId, list);
  }

  // Prepara per il motore tutti i giorni del viaggio con le loro tappe, così
  // può cercare dove ricollocare una tappa che oggi non ci sta.
  function trovaGiorniAlternativi(stopId, dayId) {
    if (!window.Giornata || !window.Giornata.giorniAlternativi) return [];
    var tappa = allStops().find(function (x) { return x.id === stopId; });
    var oggi = dayById(dayId);
    if (!tappa || !oggi) return [];
    var giorni = DAYS.map(function (d) {
      return { id: d.id, date: d.date, city: d.city, tappe: stopsForDay(d.id) };
    });
    return window.Giornata.giorniAlternativi(tappa, giorni, dayId, window.TRAVI_ORARI, oggi.city);
  }

  // Sposta davvero la tappa: cambia il giorno e le dà un orario coerente con
  // la posizione trovata dal motore, così non finisce in fondo alla lista.
  function spostaTappa(stopId, versoGiorno, dopoTitolo) {
    var tappa = allStops().find(function (x) { return x.id === stopId; });
    if (!tappa) return;
    var dest = stopsForDay(versoGiorno);
    var nuovaOra = "09:00";
    if (dopoTitolo) {
      var rif = dest.find(function (x) { return x.title === dopoTitolo; });
      if (rif) {
        var m = window.Giornata.min(rif.time) + (rif.dur || 0) + 15;
        nuovaOra = window.Giornata.hhmm(m).replace("+1", "");
      }
    } else if (dest.length) {
      nuovaOra = window.Giornata.hhmm(Math.max(0, window.Giornata.min(dest[0].time) - 60));
    }
    var patch = { day: versoGiorno, time: nuovaOra };
    var isCustom = state.custom.some(function (c) { return c.id === stopId; });
    if (isCustom) {
      state.custom = state.custom.map(function (c) {
        return c.id === stopId ? Object.assign({}, c, patch) : c;
      });
    } else {
      state.overrides[stopId] = Object.assign({}, state.overrides[stopId] || {}, patch);
    }
    persist();
    toast("Spostata al " + (dayById(versoGiorno) || {}).date);
  }

  function agganciaProva(dayId, list) {
    var on = document.getElementById("gps-on");
    if (on) on.onclick = accendiGPS;
    var off = document.getElementById("gps-off");
    if (off) off.onclick = spegniGPS;
    var sp = document.querySelector(".consiglio .sposta");
    if (sp) sp.onclick = function () {
      spostaTappa(this.dataset.tappa, this.dataset.giorno, this.dataset.dopo || null);
    };
    var apri = document.getElementById("prova-apri");
    if (apri) apri.onclick = function () {
      simula.attiva = true; simula.minuti = oraDiAdesso();
      renderStatoGiornata(dayId, list);
    };
    var chiudi = document.getElementById("prova-chiudi");
    if (chiudi) chiudi.onclick = function () {
      simula.attiva = false; renderStatoGiornata(dayId, list);
    };
    var sl = document.getElementById("prova-slider");
    if (sl) sl.oninput = function () {
      simula.minuti = +this.value;
      renderStatoGiornata(dayId, list);
      var n = document.getElementById("prova-slider");
      if (n) { n.focus(); } // resta sotto il dito mentre si trascina
    };
  }

  // Segna/toglie "fatto" direttamente dalla lista, senza aprire il foglio:
  // è l'azione che serve più spesso durante il viaggio vero, quindi deve
  // costare un tocco solo.
  function toggleDone(id) {
    var cur = allStops().find(function (x) { return x.id === id; });
    if (!cur) return;
    var novo = !cur.done;
    var isCustom = state.custom.some(function (c) { return c.id === id; });
    if (isCustom) {
      state.custom = state.custom.map(function (c) { return c.id === id ? Object.assign({}, c, { done: novo }) : c; });
    } else {
      state.overrides[id] = Object.assign({}, state.overrides[id] || {}, { done: novo });
    }
    persist();
  }

  function renderItinerario() {
    if (!DAYS.length || !selectedDay.itinerario) return;
    document.getElementById("itin-city").textContent = dayById(selectedDay.itinerario).city;
    document.getElementById("itin-theme").textContent = dayById(selectedDay.itinerario).theme;
    var list = stopsForDay(selectedDay.itinerario);
    renderStatoGiornata(selectedDay.itinerario, list);
    var el = document.getElementById("stoplist");
    el.innerHTML = "";
    list.forEach(function (s) {
      var prio = window.Giornata ? window.Giornata.prioDi(s) : (s.prio || "norm");
      var card = document.createElement("div");
      card.className = "stopcard" + (s.done ? " done" : "");
      card.innerHTML =
        '<div class="thumb" style="background-image:url(\'' + imgFor(s) + '\')">' +
        (prio === "top" ? '<span class="prio-badge"><svg><use href="#ic-star"/></svg></span>' : "") +
        "</div>" +
        '<div class="content">' +
        '<div class="meta-top"><span class="time num">' + s.time + "</span>" +
        (s.locked ? '<span class="lockdot">🔒</span>' : "") + "</div>" +
        '<div class="title">' + escapeHtml(s.title) + "</div>" +
        '<div class="sub">' + escapeHtml(s.sub || "") + "</div>" +
        '<div class="tags">' +
        '<span class="chip">' + iconFor(s.cat) + cat(s.cat).label + "</span>" +
        (s.dur ? '<span class="chip">' + s.dur + " min</span>" : "") +
        (s.tmin ? '<span class="chip">' + tIconFor(s.tmode) + s.tmin + " min</span>" : "") +
        (s.locked ? '<span class="chip locked-chip">🔒 Confermato</span>' : "") +
        "</div>" +
        "</div>" +
        '<button class="quickdone' + (s.done ? " on" : "") + '" aria-label="Segna come completata"><svg><use href="#ic-check"/></svg></button>';
      card.addEventListener("click", function () { openSheet(s.id); });
      card.querySelector(".quickdone").addEventListener("click", function (e) {
        e.stopPropagation();
        toggleDone(s.id);
      });
      el.appendChild(card);
    });
    if (list.length === 0) {
      el.innerHTML = '<div style="text-align:center;color:var(--text-muted);padding:30px 10px;font-size:.85rem;">Nessuna tappa per questo giorno. Aggiungetene una qui sotto.</div>';
    }
  }

  // Mappa vera (Leaflet + Stadia Alidade Smooth), a schermo intero. Il giorno
  // mostrato è SEMPRE quello scelto in Itinerario — niente selettore proprio:
  // Itinerario resta l'unica fonte di verità su "che giorno stiamo guardando".
  // Il fondo mappa è autorizzato per dominio nel pannello Stadia, quindi qui
  // non c'è nessuna chiave: se un giorno le piastrelle sparissero, è là che va
  // aggiunto il dominio nuovo.
  var mappa = null, stratoTappe = null, markerRefs = [], mapSelIdx = 0, mapLastDay = null, mapPunti = [];

  function creaMappa() {
    if (mappa || typeof L === "undefined") return mappa;
    mappa = L.map("map", { zoomControl: true, attributionControl: true });
    L.tileLayer("https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png", {
      attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a> &copy; OpenStreetMap',
      maxZoom: 19
    }).addTo(mappa);
    stratoTappe = L.layerGroup().addTo(mappa);
    mappa.setView([35.68, 139.76], 11);
    return mappa;
  }

  function iconaPin(numero, selezionata) {
    return L.divIcon({
      className: "", html: '<div class="pin-num' + (selezionata ? " sel" : "") + '">' + numero + "</div>",
      iconSize: [26, 26], iconAnchor: [13, 13]
    });
  }

  function renderMappa() {
    if (!DAYS.length || !selectedDay.itinerario) return;
    var dayId = selectedDay.itinerario;
    var list = stopsForDay(dayId);
    var day = dayById(dayId);

    var pill = document.getElementById("map-daypill");
    if (pill && day) pill.textContent = day.city + " · " + weekdayShort(day.date) + " " + dayNum(day.date);

    // Quando si cambia giorno si riparte dalla prossima tappa non fatta;
    // dentro lo stesso giorno la selezione (tappa scelta col tocco o con le
    // frecce) resta dov'era.
    if (dayId !== mapLastDay) {
      mapLastDay = dayId;
      var primoNonFatto = list.findIndex(function (s) { return !s.done; });
      mapSelIdx = primoNonFatto === -1 ? 0 : primoNonFatto;
    }
    if (mapSelIdx >= list.length) mapSelIdx = Math.max(0, list.length - 1);

    // Pin numerati + percorso del giorno. I numeri corrispondono all'ordine
    // delle tappe, così mappa e card in basso si leggono insieme.
    var m = creaMappa();
    markerRefs = [];
    mapPunti = [];
    if (m) {
      stratoTappe.clearLayers();
      var punti = mapPunti;
      list.forEach(function (s, i) {
        if (s.lat == null || s.lon == null) return;
        var mk = L.marker([s.lat, s.lon], { icon: iconaPin(i + 1, i === mapSelIdx) }).addTo(stratoTappe);
        mk.on("click", (function (idx) { return function () { selezionaTappaMappa(idx); }; })(i));
        markerRefs[i] = mk;
        punti.push([s.lat, s.lon]);
      });
      if (punti.length > 1) {
        L.polyline(punti, { color: "#F5503C", weight: 3, opacity: .6, dashArray: "6 7" })
          .addTo(stratoTappe);
      }
      // Dove siete adesso, se il telefono lo sta dicendo. Volutamente FUORI
      // dai punti usati per l'inquadratura: se foste a 40 km dalla giornata,
      // includervi vorrebbe dire non vedere più le tappe.
      if (posizione) {
        L.marker([posizione.lat, posizione.lon], {
          icon: L.divIcon({ className: "", html: '<div class="gps-dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }),
          interactive: false
        }).addTo(stratoTappe);
      }
      inquadraGiornata();
    }

    aggiornaMapCard(list);
  }

  // Inquadratura di partenza: TUTTE le tappe del giorno nello schermo, senza
  // doverle cercare a mano con zoom avanti e indietro. Va rifatta quando la
  // pagina Mappa torna visibile: se la mappa viene disegnata mentre la vista è
  // nascosta, Leaflet misura un contenitore alto zero e l'inquadratura esce
  // sbagliata (era questo il motivo per cui bisognava sempre rizoomare).
  function inquadraGiornata() {
    if (!mappa || !mapPunti.length) return;
    mappa.invalidateSize();
    if (mapPunti.length === 1) mappa.setView(mapPunti[0], 15);
    else mappa.fitBounds(mapPunti, { padding: [40, 70] });
  }

  // Tocco su un pin, o sulle frecce della card: cambia solo quale tappa è
  // "a fuoco" in basso, senza ridisegnare tutta la mappa.
  function selezionaTappaMappa(idx) {
    mapSelIdx = idx;
    markerRefs.forEach(function (mk, i) {
      if (mk) mk.setIcon(iconaPin(i + 1, i === idx));
    });
    var list = stopsForDay(selectedDay.itinerario);
    var s = list[idx];
    // Toccare un numero entra nel dettaglio di quella tappa: si vede la via,
    // non più la città intera. Il tasto in basso a destra rimette in quadro
    // tutta la giornata.
    if (s && s.lat != null && mappa) {
      mappa.setView([s.lat, s.lon], Math.max(mappa.getZoom(), 16), { animate: true });
    }
    aggiornaMapCard(list);
  }

  function aggiornaMapCard(list) {
    var body = document.getElementById("map-card-body");
    if (!body) return;
    var s = list[mapSelIdx];
    if (!s) {
      body.innerHTML = '<div class="empty">Nessuna tappa da mostrare per questo giorno.</div>';
      return;
    }
    var o = (window.TRAVI_ORARI || {})[s.id];
    var chiude = (o && o.tipo === "orari") ? ("chiude " + o.ch) : "";

    // Quanto ci vuole per arrivarci dalla tappa precedente: il tempo previsto
    // nei dati se c'è, altrimenti la stima a piedi dalle coordinate — lo
    // stesso numero che usa il motore della giornata (js/giornata.js).
    var tempo = "", prec = mapSelIdx > 0 ? list[mapSelIdx - 1] : null;
    var primaDaFare = list.findIndex(function (x) { return !x.done; });
    if (posizione && mapSelIdx === primaDaFare && window.Giornata) {
      var kmQui = window.Giornata.kmTra(posizione, s);
      var minQui = window.Giornata.minutiAPiedi(posizione, s);
      if (kmQui != null && kmQui <= 5) tempo = minQui + " min a piedi da qui";
      else if (kmQui != null) tempo = distanzaLeggibile(kmQui) + " da qui";
    } else if (s.tmin) {
      tempo = s.tmin + " min " + (s.tmode === "walk" ? "a piedi" : "di spostamento");
    } else if (prec && window.Giornata) {
      var km = window.Giornata.kmTra(prec, s);
      var piedi = window.Giornata.minutiAPiedi(prec, s);
      if (piedi != null && km != null && km <= 5) tempo = piedi + " min a piedi";
    }

    // Riga tempi: quanto ci vuole ad arrivarci e, se chiude, a che ora — sono
    // le due cose che servono guardando la mappa in mezzo alla strada.
    var riga2 = [tempo, chiude].filter(Boolean).join(" · ");
    body.innerHTML =
      '<div class="thumb" style="background-image:url(\'' + imgFor(s) + '\')"></div>' +
      '<div class="info">' +
      '<div class="title">' + escapeHtml(s.title) + "</div>" +
      '<div class="sub">' + s.time + (s.sub ? " · " + escapeHtml(s.sub) : "") + "</div>" +
      (riga2 ? '<div class="tempo"><svg><use href="#ic-walk"/></svg>' + riga2 + "</div>" : "") +
      "</div>" +
      '<svg class="chev"><use href="#ic-chev"/></svg>';
    body.onclick = function () { openSheet(s.id); };
  }

  function renderHome() {
    if (!DAYS.length) return;
    var now = new Date();
    var isTripLive = todayISO() >= TRIP.start && todayISO() <= TRIP.end;
    var refDayId = isTripLive ? defaultDay() : DAYS[0].id;
    var refDay = dayById(refDayId);
    if (!refDay) return;

    document.getElementById("hero-city").textContent = refDay.city;
    document.getElementById("hero-date").textContent = formatDateLong(refDay.date) + " · " + refDay.theme;
    var hr = now.getHours();
    var greet = hr < 12 ? "Buongiorno" : hr < 18 ? "Buon pomeriggio" : "Buonasera";
    document.getElementById("hero-phase").textContent = greet + ", Sebastian & Alessandra" + (isTripLive ? " — siete in viaggio" : "");
    updateWeather(refDay);

    var list = stopsForDay(refDayId);
    var done = list.filter(function (s) { return s.done; }).length;
    document.getElementById("home-count").innerHTML = list.length + " <small>luoghi in programma</small>";
    var pct = list.length ? Math.round((done / list.length) * 100) : 0;
    document.getElementById("home-pct").textContent = pct + "%";
    var ring = document.getElementById("ring-fg");
    if (ring) {
      var circ = 263.9; // 2·π·42 (raggio del cerchio in index.html)
      ring.style.strokeDashoffset = String(circ - (circ * pct / 100));
    }
    document.getElementById("home-done-lbl").textContent =
      done === 0 ? "Nessuna tappa completata ancora" :
      (done === list.length ? "Giornata completata" : done + " di " + list.length + " completate");
    document.getElementById("home-stops-total").textContent = allStops().length;

    var startDiff = Math.ceil((new Date(TRIP.start + "T09:00:00") - now) / 86400000);

    if (!isTripLive && startDiff > 0) {
      document.getElementById("hero-big").textContent = startDiff;
      document.getElementById("hero-lbl").textContent = "giorni al vostro primo passo in Giappone.";
    } else if (!isTripLive && startDiff <= 0) {
      document.getElementById("hero-big").textContent = "🎊";
      document.getElementById("hero-lbl").textContent = "Il viaggio è concluso: ogni tappa resta qui, pronta da rivivere.";
    } else {
      document.getElementById("hero-big").textContent = refDay.city;
      document.getElementById("hero-lbl").textContent = refDay.theme + " — oggi è il giorno " + (DAYS.findIndex(function (d) { return d.id === refDayId; }) + 1) + " di " + DAYS.length + ".";
    }

    var pending = list.filter(function (s) { return !s.done; });
    var next = pending[0];
    var glyph = document.getElementById("next-glyph");
    if (next) {
      document.getElementById("next-title").textContent = next.title;
      glyph.classList.add("has-img");
      glyph.style.backgroundImage = "url('" + imgFor(next) + "')";
      var mins = timeToMin(next.time) - (now.getHours() * 60 + now.getMinutes());
      var whenTxt = next.time + (next.sub ? " · " + next.sub : "");
      if (isTripLive && refDayId === defaultDay() && mins > 0 && mins < 600) {
        whenTxt = "tra " + mins + " min · " + next.sub;
      }
      document.getElementById("next-meta").textContent = whenTxt;
      document.getElementById("next-card").onclick = function () { switchView("itinerario"); selectedDay.itinerario = refDayId; renderAll(); };
    } else {
      document.getElementById("next-title").textContent = list.length ? "Giornata completata" : "Nessuna tappa";
      document.getElementById("next-meta").textContent = list.length ? "Bel lavoro — godetevi il resto della giornata." : "Aggiungete la prima tappa dall'Itinerario.";
      glyph.classList.remove("has-img");
      glyph.style.backgroundImage = "";
    }
  }

  /* ---------- meteo live (Open-Meteo: gratuito, senza chiave API) ----------
     Le previsioni reali coprono solo circa le prossime 2 settimane: finché il
     viaggio è più lontano di così, resta il testo statico "clima tipico" già
     nell'HTML. Quando ci si avvicina, questo lo sostituisce in automatico con
     una previsione vera per la città del giorno. */
  var weatherFetchedFor = null;
  // Codici WMO (li usa Open-Meteo) ridotti alle famiglie che contano per un
  // colpo d'occhio: icona + parola, non il bollettino completo.
  var WMO = {
    0: ["ic-sun", "Sereno"], 1: ["ic-sun", "Poco nuvoloso"], 2: ["ic-cloud", "Parzialmente nuvoloso"], 3: ["ic-cloud", "Nuvoloso"],
    45: ["ic-cloud", "Nebbia"], 48: ["ic-cloud", "Nebbia"],
    51: ["ic-rain", "Pioggerella"], 53: ["ic-rain", "Pioggerella"], 55: ["ic-rain", "Pioggerella"],
    61: ["ic-rain", "Pioggia debole"], 63: ["ic-rain", "Pioggia"], 65: ["ic-rain", "Pioggia forte"],
    71: ["ic-snow", "Neve debole"], 73: ["ic-snow", "Neve"], 75: ["ic-snow", "Neve forte"],
    80: ["ic-rain", "Rovesci"], 81: ["ic-rain", "Rovesci"], 82: ["ic-rain", "Rovesci forti"],
    95: ["ic-rain", "Temporale"], 96: ["ic-rain", "Temporale"], 99: ["ic-rain", "Temporale"]
  };
  function updateWeather(refDay) {
    if (!refDay) return;
    var today = new Date();
    var dayDate = new Date(refDay.date + "T00:00:00");
    var daysUntil = Math.round((dayDate - new Date(today.getFullYear(), today.getMonth(), today.getDate())) / 86400000);
    if (daysUntil < 0 || daysUntil > 15) return; // fuori dalla finestra di previsione: resta il testo statico
    var cacheKey = refDay.date;
    if (weatherFetchedFor === cacheKey) return;
    var city = cityKeyFor(refDay.city);
    var coords = CITY_COORDS[city];
    if (!coords) return;
    var url = "https://api.open-meteo.com/v1/forecast?latitude=" + coords.lat + "&longitude=" + coords.lon +
      "&daily=temperature_2m_max,temperature_2m_min,weathercode&timezone=Asia%2FTokyo&start_date=" + refDay.date + "&end_date=" + refDay.date;
    fetch(url).then(function (r) { return r.json(); }).then(function (data) {
      if (!data || !data.daily || !data.daily.temperature_2m_max || !data.daily.temperature_2m_max.length) return;
      weatherFetchedFor = cacheKey;
      var lo = Math.round(data.daily.temperature_2m_min[0]);
      var hi = Math.round(data.daily.temperature_2m_max[0]);
      var code = data.daily.weathercode ? data.daily.weathercode[0] : null;
      var info = WMO[code] || null;
      var tEl = document.getElementById("weather-t");
      var cEl = document.getElementById("weather-cond");
      var iEl = document.getElementById("weather-icon");
      if (tEl) tEl.textContent = lo + "–" + hi + "°";
      if (cEl) cEl.textContent = (info ? info[1] : "Previsione") + " per " + city;
      if (iEl && info) { var use = iEl.querySelector("use"); if (use) use.setAttribute("href", "#" + info[0]); }
    }).catch(function () { /* offline o API non raggiungibile: resta il testo statico */ });
  }

  function formatDateLong(dateStr) {
    var months = ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"];
    var d = new Date(dateStr + "T00:00:00");
    return d.getDate() + " " + months[d.getMonth()] + " " + d.getFullYear();
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function renderAll() {
    if (!dataLoaded) return;
    renderDayRow("dayrow-itin", "itinerario");
    renderItinerario();
    renderMappa();
    renderHome();
    renderBudget();
    renderPreferiti();
    renderPrenotazioni();
    aggiornaRigaCambio();
    aggiornaRigaDiario();
  }

  // Frecce della card della Mappa: cambiano solo la tappa a fuoco, come
  // toccare un pin diverso. Collegate una volta sola, non ad ogni render.
  document.getElementById("map-prev").addEventListener("click", function () {
    var list = stopsForDay(selectedDay.itinerario);
    if (!list.length) return;
    selezionaTappaMappa((mapSelIdx - 1 + list.length) % list.length);
  });
  document.getElementById("map-next").addEventListener("click", function () {
    var list = stopsForDay(selectedDay.itinerario);
    if (!list.length) return;
    selezionaTappaMappa((mapSelIdx + 1) % list.length);
  });
  // La pillola in alto RIPORTA il giorno scelto in Itinerario, non lo sceglie:
  // toccarla porta all'Itinerario, dove il giorno si cambia davvero.
  document.getElementById("map-daypill").addEventListener("click", function () { switchView("itinerario"); });
  document.getElementById("map-fit").addEventListener("click", inquadraGiornata);

  /* ---------- budget extra ---------- */
  function fmtEuro(n) {
    return "€" + (Math.round(n * 100) / 100).toLocaleString("it-IT", { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
  }
  function whoLabel(id) {
    var w = BUDGET_WHO.find(function (x) { return x.id === id; });
    return w ? w.label : id;
  }
  function renderBudget() {
    var total = state.budget.reduce(function (sum, it) { return sum + (Number(it.amount) || 0); }, 0);
    document.getElementById("budget-total-home").textContent = fmtEuro(total);
    document.getElementById("budget-count-home").textContent = state.budget.length + (state.budget.length === 1 ? " spesa" : " spese");
    var sub = document.getElementById("rm-budget-sub");
    if (sub) sub.textContent = state.budget.length + (state.budget.length === 1 ? " spesa · " : " spese · ") + fmtEuro(total);
    var totalEl = document.getElementById("budget-total");
    if (totalEl) totalEl.textContent = fmtEuro(total);
    var list = document.getElementById("budget-list");
    if (!list) return;
    list.innerHTML = "";
    if (!state.budget.length) {
      list.innerHTML = '<div class="budget-empty">Nessuna spesa extra registrata ancora.</div>';
      return;
    }
    state.budget.slice().sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); }).forEach(function (it) {
      var row = document.createElement("div");
      row.className = "budget-item";
      row.innerHTML =
        '<div class="bi-main"><div class="bi-title">' + escapeHtml(it.title) + '</div><div class="bi-who">' + whoLabel(it.who) + '</div></div>' +
        '<div class="bi-amount num">' + fmtEuro(Number(it.amount) || 0) + '</div>' +
        '<button class="bi-del" data-id="' + it.id + '">✕</button>';
      row.querySelector(".bi-del").addEventListener("click", function () {
        state.budget = state.budget.filter(function (x) { return x.id !== it.id; });
        persist();
      });
      list.appendChild(row);
    });
  }

  /* ---------- view switching ---------- */
  function switchView(name) {
    document.querySelectorAll(".view").forEach(function (v) { v.classList.remove("active"); });
    var view = document.getElementById("view-" + name);
    view.classList.add("active");
    document.querySelectorAll(".tab").forEach(function (t) { t.classList.toggle("active", t.dataset.view === name); });
    // Il "+" fluttuante serve sia in Itinerario (nuova tappa) sia in Preferiti
    // (nuovo preferito): cosa apre dipende da dove ci si trova.
    var fabAdd = document.getElementById("fab-add");
    fabAdd.style.display = (name === "itinerario" || name === "preferiti") ? "flex" : "none";
    fabAdd.onclick = (name === "preferiti") ? function () { openFavSheet(); } : function () { openSheet(null); };
    // ogni volta che si cambia pagina dal menu, si riparte sempre dall'inizio di quella pagina
    var sc = view.querySelector(".scroll");
    if (sc) sc.scrollTop = 0;
    // Leaflet misura il contenitore quando lo crea: se la vista era nascosta
    // trova altezza zero e disegna la mappa storta. Va rimisurata ogni volta
    // che la pagina Mappa torna visibile.
    if (name === "mappa" && mappa) { setTimeout(inquadraGiornata, 60); }
  }
  document.querySelectorAll(".tab").forEach(function (t) {
    t.addEventListener("click", function () { switchView(t.dataset.view); });
  });

  /* ---------- sheet (add/edit stop) ---------- */
  var backdrop = document.getElementById("backdrop");
  var sheet = document.getElementById("sheet");

  function buildPickrow(containerId, items) {
    var el = document.getElementById(containerId);
    el.innerHTML = "";
    items.forEach(function (it) {
      var p = document.createElement("div");
      p.className = "pick";
      p.dataset.id = it.id;
      p.innerHTML = (it.icon ? '<svg><use href="#' + it.icon + '"/></svg>' : "") + it.label;
      p.addEventListener("click", function () {
        el.querySelectorAll(".pick").forEach(function (x) { x.classList.remove("sel"); });
        p.classList.add("sel");
      });
      el.appendChild(p);
    });
  }
  buildPickrow("f-category", CATS);
  buildPickrow("f-transport", TRANSPORTS);
  buildPickrow("f-priorita", PRIORITA);
  buildPickrow("f-duration-chips", DURATA_OPTS);
  buildPickrow("fav-category", CATS);
  buildPickrow("fav-priorita", PRIORITA);

  // Sceglie il chip di durata più vicino a un valore qualunque (dati vecchi,
  // o una tappa senza durata mai compilata): il campo non è mai vuoto.
  function selectDurataVicina(dur) {
    var target = dur || 30;
    var migliore = DURATA_OPTS[0], diffMin = Infinity;
    DURATA_OPTS.forEach(function (o) {
      var diff = Math.abs(parseInt(o.id, 10) - target);
      if (diff < diffMin) { diffMin = diff; migliore = o; }
    });
    selectPick("f-duration-chips", migliore.id);
  }

  function selectPick(containerId, id) {
    document.getElementById(containerId).querySelectorAll(".pick").forEach(function (p) {
      p.classList.toggle("sel", p.dataset.id === id);
    });
  }
  function getPick(containerId) {
    var sel = document.getElementById(containerId).querySelector(".pick.sel");
    return sel ? sel.dataset.id : null;
  }

  /* ---------- fogli: sfondo fermo e chiusura col trascinamento ----------
     Con un foglio aperto il dito che scorreva sopra il foglio faceva scorrere
     la PAGINA SOTTO: iOS, quando il contenuto sotto il dito non ha niente da
     scorrere, passa il gesto al primo contenitore scorrevole che trova
     salendo. Mettere overflow:hidden sulla vista non bastava, perché il foglio
     è position:fixed e quindi fuori da quella vista.
     Qui si fa la cosa giusta: finché un foglio è aperto, ogni trascinamento
     che non sia dentro una zona che può DAVVERO scorrere viene fermato. */
  var foglioAperto = false;

  function bloccaSfondo(bloccato) {
    foglioAperto = bloccato;
    document.querySelectorAll(".scroll").forEach(function (el) {
      el.style.overflowY = bloccato ? "hidden" : "auto";
    });
  }

  // Risale dal punto toccato cercando un contenitore che possa scorrere per
  // davvero (ha contenuto in eccesso ED è impostato per scorrere).
  function trovaScorrevole(el, limite) {
    while (el && el !== limite && el !== document.body) {
      if (el.scrollHeight > el.clientHeight + 1) {
        var ov = getComputedStyle(el).overflowY;
        if (ov === "auto" || ov === "scroll") return el;
      }
      el = el.parentElement;
    }
    return null;
  }

  document.addEventListener("touchmove", function (e) {
    if (!foglioAperto) return;
    if (trovaScorrevole(e.target, null)) return; // può scorrere: lascialo fare
    e.preventDefault();                          // altrimenti non si muove niente
  }, { passive: false });

  /* Chiusura col trascinamento verso il basso.
     Il foglio segue il dito, lo sfondo scuro si schiarisce man mano: si vede
     che si sta "tirando giù la tendina". Lasciandolo prima di metà strada
     torna su da solo, oltre la soglia scivola via e si chiude. Verso l'alto
     resiste e si ferma quasi subito, come i fogli di sistema.
     Si trascina solo se il contenuto è già in cima: se il foglio è più lungo
     dello schermo, il primo gesto verso il basso lo riporta in cima, e solo
     il successivo lo chiude — come ci si aspetta su iPhone. */
  var SOGLIA_CHIUSURA = 120;

  function rendiTrascinabile(sheet, chiudi) {
    var y0 = 0, dy = 0, trascina = false;

    sheet.addEventListener("touchstart", function (e) {
      if (e.touches.length !== 1) { trascina = false; return; }
      // dai controlli di sistema (orario, campi di testo) non si trascina
      if (e.target.closest && e.target.closest("input, textarea, select")) { trascina = false; return; }
      var zona = trovaScorrevole(e.target, sheet.parentElement);
      trascina = !zona || zona.scrollTop <= 0;
      y0 = e.touches[0].clientY;
      dy = 0;
      sheet.style.transition = "none";
      backdrop.style.transition = "none"; // deve seguire il dito, non arrivare dopo
    }, { passive: true });

    sheet.addEventListener("touchmove", function (e) {
      if (!trascina || e.touches.length !== 1) return;
      dy = e.touches[0].clientY - y0;
      if (dy < 0) dy = Math.max(-40, dy / 4); // in su: resistenza, va quasi a zero
      if (dy > 0) e.preventDefault();
      sheet.style.transform = "translate(-50%, " + dy + "px)";
      var quanto = Math.min(1, Math.max(0, dy / 300));
      backdrop.style.opacity = String(1 - quanto * 0.9);
    }, { passive: false });

    ["touchend", "touchcancel"].forEach(function (ev) {
      sheet.addEventListener(ev, function () {
        if (!trascina) return;
        trascina = false;
        sheet.style.transition = "";
        backdrop.style.transition = "";
        if (dy > SOGLIA_CHIUSURA) {
          // scivola via fino in fondo e poi chiude, senza scatti
          sheet.style.transform = "translate(-50%, 100%)";
          backdrop.style.opacity = "";
          chiudi();
          setTimeout(function () { sheet.style.transform = ""; }, 320);
        } else {
          sheet.style.transform = "";   // torna al suo posto con la transizione
          backdrop.style.opacity = "";
        }
        dy = 0;
      });
    });
  }

  // Un posto senza coordinate non può avere un pin sulla mappa. Se è stato
  // scritto a mano invece che scelto dalla ricerca, le cerchiamo noi in
  // background: così qualunque tappa aggiunta — anche partendo dai Preferiti —
  // finisce da sola sulla mappa col suo numero, senza doverci pensare.
  function trovaCoordinate(titolo, zona) {
    if (!window.TraviCerca) return Promise.resolve(null);
    return window.TraviCerca.cerca((titolo + " " + (zona || "")).trim()).then(function (r) {
      return (r && r.length) ? { lat: r[0].lat, lon: r[0].lon } : null;
    }).catch(function () { return null; });
  }

  // Applica una modifica a una tappa, che sia una aggiunta da voi (custom) o
  // una del programma originale (dove le modifiche vivono negli overrides).
  function applicaPatchTappa(id, patch) {
    var isCustom = state.custom.some(function (c) { return c.id === id; });
    if (isCustom) {
      state.custom = state.custom.map(function (c) { return c.id === id ? Object.assign({}, c, patch) : c; });
    } else {
      state.overrides[id] = Object.assign({}, state.overrides[id] || {}, patch);
    }
    persist();
  }

  // Ricordano, per la tappa in modifica, ciò che non ha un campo di testo suo:
  // la posizione trovata cercando il posto, e una foto già presente da non
  // ricercare di nuovo se non cambia il posto.
  var sheetLatLon = null, sheetExistingFoto = null;

  function openSheet(stopId) {
    editingId = stopId || null;
    var s = editingId ? allStops().find(function (x) { return x.id === editingId; }) : null;
    var locked = !!(s && s.locked);
    sheetLatLon = (s && s.lat != null) ? { lat: s.lat, lon: s.lon } : null;
    sheetExistingFoto = (s && s.foto) ? s.foto : null;

    document.getElementById("sheet-title").textContent = s ? "Modifica tappa" : "Nuova tappa";
    document.getElementById("f-cerca").value = "";
    document.getElementById("cerca-risultati").hidden = true;
    document.getElementById("f-title").value = s ? s.title : "";
    document.getElementById("f-sub").value = s ? s.sub || "" : "";
    document.getElementById("f-time").value = s ? s.time : "09:00";
    selectDurataVicina(s ? s.dur : 30);
    document.getElementById("f-travel").value = s ? s.tmin || 0 : 0;
    document.getElementById("f-notes").value = s ? s.notes || "" : "";
    selectPick("f-category", s ? s.cat : "experience");
    selectPick("f-transport", s ? s.tmode : "walk");
    // Se la tappa non ha una priorità sua, si mostra quella dedotta dalla
    // categoria: così il campo non è mai vuoto e si capisce cosa farà il motore.
    selectPick("f-priorita", (s && window.Giornata) ? window.Giornata.prioDi(s)
               : (s && s.prio) || "norm");
    var done = !!(s && s.done);
    var fDone = document.getElementById("f-done");
    fDone.classList.toggle("on", done);
    etichettaFatto(fDone);
    document.getElementById("btn-delete").style.display = (s && !locked) ? "block" : "none";
    document.getElementById("lock-note").hidden = !locked;
    sheet.querySelector(".sheet-body").classList.toggle("locked", locked);
    ["f-title", "f-sub", "f-time", "f-travel", "f-notes"].forEach(function (id) {
      document.getElementById(id).disabled = locked;
    });

    // Link rapidi verso Google/Apple Maps: solo su una tappa che già esiste
    // (per una nuova non c'è ancora niente da aprire).
    var gmaps = document.getElementById("link-gmaps");
    if (s) {
      gmaps.hidden = false;
      var gq = encodeURIComponent(s.q || (s.title + " " + (s.sub || "")));
      // Con la posizione accesa il tasto non cerca il posto: ci porta. Il
      // percorso vero lo fa Google Maps — Travi resta il cervello, le gambe
      // sono le loro (vedi DESIGN-DECISIONI.md).
      var dest = (s.lat != null) ? (s.lat + "," + s.lon) : gq;
      gmaps.href = posizione
        ? "https://www.google.com/maps/dir/?api=1&origin=" + posizione.lat + "," + posizione.lon +
          "&destination=" + dest + "&travelmode=walking"
        : "https://www.google.com/maps/search/?api=1&query=" + gq;
      document.getElementById("link-amaps").href = "https://maps.apple.com/?q=" + gq;
    } else {
      gmaps.hidden = true;
    }

    // Testa illustrata: foto + nome + zona. Solo su una tappa che esiste già.
    // E se la tappa esiste già, i campi del nome partono chiusi (il nome è
    // scritto sulla foto): il foglio si apre corto, con davanti solo le cose
    // che si toccano davvero durante la giornata.
    document.getElementById("sez-posto").hidden = !!s;
    document.getElementById("posto-toggle").hidden = !s;
    document.getElementById("posto-toggle").classList.remove("open");

    var hero = document.getElementById("sheet-hero");
    if (s) {
      hero.hidden = false;
      document.getElementById("sheet-hero-img").style.backgroundImage = "url('" + imgFor(s) + "')";
      document.getElementById("sheet-hero-title").textContent = s.title;
      document.getElementById("sheet-hero-sub").textContent = s.time + (s.sub ? " · " + s.sub : "");
      var prioTop = window.Giornata ? window.Giornata.prioDi(s) === "top" : s.prio === "top";
      document.getElementById("sheet-hero-prio").hidden = !prioTop;
    } else {
      hero.hidden = true;
    }

    document.getElementById("altro-body").hidden = true;
    document.getElementById("altro-toggle").classList.remove("open");

    sheet.style.transform = "";
    backdrop.classList.add("show");
    sheet.classList.add("show");
    bloccaSfondo(true);
  }
  function closeSheet() {
    backdrop.classList.remove("show");
    sheet.classList.remove("show");
    bloccaSfondo(false);
    editingId = null;
  }
  document.getElementById("sheet-close").addEventListener("click", closeSheet);
  backdrop.addEventListener("click", closeSheet);
  // Il tasto dice in che stato si è, non solo con il colore: da spento invita
  // a segnarla, da acceso conferma che è fatta (e si può ancora tornare indietro).
  function etichettaFatto(btn) {
    btn.querySelector("span").textContent = btn.classList.contains("on")
      ? "Completata" : "Segna come completata";
  }
  document.getElementById("f-done").addEventListener("click", function () {
    this.classList.toggle("on");
    etichettaFatto(this);
  });
  document.getElementById("altro-toggle").addEventListener("click", function () {
    var body = document.getElementById("altro-body");
    var apri = body.hidden;
    body.hidden = !apri;
    this.classList.toggle("open", apri);
  });
  document.getElementById("posto-toggle").addEventListener("click", function () {
    var body = document.getElementById("sez-posto");
    var apri = body.hidden;
    body.hidden = !apri;
    this.classList.toggle("open", apri);
  });

  // Cerca il posto (Nominatim, vedi js/cerca-luogo.js): riempie titolo, zona e
  // posizione da un risultato scelto, invece di doverli scrivere a mano.
  function agganciaRicerca(inputId, boxId, onScelta) {
    var timer = null;
    document.getElementById(inputId).addEventListener("input", function () {
      var q = this.value;
      clearTimeout(timer);
      timer = setTimeout(function () {
        var box = document.getElementById(boxId);
        if (!window.TraviCerca) return;
        window.TraviCerca.cerca(q).then(function (risultati) {
          if (!risultati.length) { box.hidden = true; box.innerHTML = ""; return; }
          box.innerHTML = "";
          risultati.forEach(function (r) {
            var row = document.createElement("div");
            row.className = "cerca-riga";
            row.innerHTML = '<div class="t">' + escapeHtml(r.title) + '</div><div class="s">' + escapeHtml(r.sub) + '</div>';
            row.addEventListener("click", function () {
              box.hidden = true;
              document.getElementById(inputId).value = "";
              onScelta(r);
            });
            box.appendChild(row);
          });
          box.hidden = false;
        });
      }, 400);
    });
  }
  agganciaRicerca("f-cerca", "cerca-risultati", function (r) {
    document.getElementById("f-title").value = r.title;
    document.getElementById("f-sub").value = r.sub;
    sheetLatLon = { lat: r.lat, lon: r.lon };
    sheetExistingFoto = null; // il posto è cambiato: la foto va ricercata di nuovo
  });

  /* ---------- Preferiti ---------- */
  // Lista dei desideri non ancora programmati: raggruppati per città, si
  // "pianificano" su un giorno preciso solo quando si vuole, verificati dallo
  // stesso motore dell'Itinerario (js/giornata.js) — mai a caso.
  function renderPreferiti() {
    var el = document.getElementById("fav-groups");
    if (!el) return;
    el.innerHTML = "";
    if (!state.favorites.length) {
      el.innerHTML = '<div style="text-align:center;color:var(--text-muted);padding:40px 20px;font-size:.85rem;">Nessun preferito ancora. Aggiungete un posto che volete vedere: potrete assegnarlo a un giorno quando volete, verificando prima se ci sta davvero.</div>';
      return;
    }
    var groups = {}, ordine = [];
    state.favorites.forEach(function (f) {
      var c = cityKeyForFav((f.sub || "") + " " + (f.title || ""));
      if (!groups[c]) { groups[c] = []; ordine.push(c); }
      groups[c].push(f);
    });
    ordine.sort(function (a, b) { return a === "Altro" ? 1 : (b === "Altro" ? -1 : a.localeCompare(b)); });
    ordine.forEach(function (city) {
      var h = document.createElement("div");
      h.className = "fav-city-heading";
      h.textContent = city;
      el.appendChild(h);
      groups[city].forEach(function (f) {
        var card = document.createElement("div");
        card.className = "fav-card";
        card.innerHTML =
          '<div class="thumb" style="background-image:url(\'' + imgFor(f) + '\')"></div>' +
          '<div class="content">' +
          '<div class="title">' + escapeHtml(f.title) + "</div>" +
          '<div class="sub">' + escapeHtml(f.sub || "") + "</div>" +
          (f.notes ? '<div class="fav-notes">' + escapeHtml(f.notes) + "</div>" : "") +
          // Dice a colpo d'occhio se il posto finirà sulla mappa quando lo
          // pianificate: la posizione ce l'ha, oppure la stiamo cercando.
          (f.lat != null
            ? '<div class="fav-pos ok"><svg><use href="#ic-pin"/></svg>posizione trovata</div>'
            : '<div class="fav-pos"><svg><use href="#ic-search"/></svg>posizione da trovare</div>') +
          "</div>" +
          '<div class="fav-actions">' +
          '<button class="fav-plan">Pianifica</button>' +
          '<button class="fav-del" aria-label="Rimuovi">✕</button>' +
          "</div>";
        card.querySelector(".fav-plan").addEventListener("click", function () { apriPreferenza(f.id); });
        card.querySelector(".fav-del").addEventListener("click", function () {
          state.favorites = state.favorites.filter(function (x) { return x.id !== f.id; });
          persist();
          toast("Rimosso dai preferiti");
        });
        el.appendChild(card);
      });
    });
  }

  /* ---------- foglio "nuovo preferito" ---------- */
  var favSheet = document.getElementById("fav-sheet");
  var favLatLon = null;

  function openFavSheet() {
    document.getElementById("fav-cerca").value = "";
    document.getElementById("fav-cerca-risultati").hidden = true;
    document.getElementById("fav-title").value = "";
    document.getElementById("fav-sub").value = "";
    document.getElementById("fav-notes").value = "";
    selectPick("fav-category", "experience");
    selectPick("fav-priorita", "norm");
    favLatLon = null;
    favSheet.style.transform = "";
    backdrop.classList.add("show");
    favSheet.classList.add("show");
    bloccaSfondo(true);
  }
  function closeFavSheet() {
    backdrop.classList.remove("show");
    favSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("fav-close").addEventListener("click", closeFavSheet);
  backdrop.addEventListener("click", closeFavSheet);
  document.getElementById("btn-add-fav").addEventListener("click", function () { openFavSheet(); });

  agganciaRicerca("fav-cerca", "fav-cerca-risultati", function (r) {
    document.getElementById("fav-title").value = r.title;
    document.getElementById("fav-sub").value = r.sub;
    favLatLon = { lat: r.lat, lon: r.lon };
  });

  document.getElementById("fav-save").addEventListener("click", function () {
    var title = document.getElementById("fav-title").value.trim();
    if (!title) { toast("Serve almeno un titolo"); return; }
    var newId = "fav-" + Date.now();
    var fav = {
      id: newId, title: title,
      sub: document.getElementById("fav-sub").value.trim(),
      cat: getPick("fav-category") || "experience",
      prio: getPick("fav-priorita") || "norm",
      notes: document.getElementById("fav-notes").value.trim(),
      createdAt: Date.now()
    };
    if (favLatLon) { fav.lat = favLatLon.lat; fav.lon = favLatLon.lon; }
    state.favorites.push(fav);
    closeFavSheet();
    persist();
    toast("Aggiunto ai preferiti");

    if (window.TraviFoto) {
      window.TraviFoto.cerca(fav.title + " " + fav.sub).then(function (url) {
        if (!url) return;
        state.favorites = state.favorites.map(function (f) { return f.id === newId ? Object.assign({}, f, { foto: url }) : f; });
        persist();
      });
    }
    // Scritto a mano senza scegliere dalla ricerca: cerchiamo noi la posizione,
    // altrimenti quando lo pianificate non avrebbe un pin sulla mappa.
    if (!favLatLon) {
      trovaCoordinate(fav.title, fav.sub).then(function (c) {
        if (!c) return;
        state.favorites = state.favorites.map(function (f) {
          return f.id === newId ? Object.assign({}, f, { lat: c.lat, lon: c.lon }) : f;
        });
        persist();
      });
    }
  });

  /* ---------- foglio "pianifica un preferito" ---------- */
  // Riusa lo stesso motore usato per lo spostamento fra giorni in Itinerario
  // (giorniAlternativi): prova ogni giorno e ogni posizione, e propone solo
  // quelli dove Travi ha VERIFICATO che c'è spazio — non un semplice elenco
  // di giorni a caso. Chi vuole decidere comunque diversamente può farlo,
  // scegliendo giorno e orario da sé più sotto.
  var assignSheet = document.getElementById("assign-sheet");

  function apriPreferenza(favId) {
    var fav = state.favorites.find(function (f) { return f.id === favId; });
    if (!fav) return;
    var tappaFinta = {
      id: fav.id, title: fav.title, sub: fav.sub, cat: fav.cat, prio: fav.prio,
      lat: fav.lat, lon: fav.lon, dur: fav.dur || 45, time: "12:00",
      done: false, locked: false
    };
    var giorni = DAYS.map(function (d) { return { id: d.id, date: d.date, city: d.city, tappe: stopsForDay(d.id) }; });
    var suggeriti = (window.Giornata && window.Giornata.giorniAlternativi)
      ? window.Giornata.giorniAlternativi(tappaFinta, giorni, "__nessuno__", window.TRAVI_ORARI, null)
      : [];
    renderAssignBody(fav, suggeriti);
    assignSheet.style.transform = "";
    backdrop.classList.add("show");
    assignSheet.classList.add("show");
    bloccaSfondo(true);
  }
  function closeAssignSheet() {
    backdrop.classList.remove("show");
    assignSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("assign-close").addEventListener("click", closeAssignSheet);
  backdrop.addEventListener("click", closeAssignSheet);

  function renderAssignBody(fav, suggeriti) {
    var body = document.getElementById("assign-body");
    var html = '<div class="assign-fav-title">' + escapeHtml(fav.title) + "</div>" +
               '<div class="assign-fav-sub">' + escapeHtml(fav.sub || "") + "</div>";
    if (suggeriti.length) {
      html += '<div class="assign-lead">Giorni dove Travi ha verificato che c’è spazio, dal più comodo:</div>';
      suggeriti.slice(0, 4).forEach(function (a) {
        html += '<button class="assign-opt" data-day="' + a.id + '" data-dopo="' + (a.dopoDi ? escapeHtml(a.dopoDi) : "") + '">' +
                '<div class="d">' + a.date.slice(8) + "/" + a.date.slice(5, 7) + " · " + escapeHtml(a.city) + "</div>" +
                '<div class="c">' + a.tappeQuelGiorno + " tappe già in programma</div>" +
                '<div class="fine">finirebbe alle ' + a.fineCon + "</div>" +
                "</button>";
      });
    } else {
      html += '<div class="assign-lead">Nessun giorno ha spazio sicuro per starci: scegliete voi, tenendo d’occhio la giornata dopo averlo aggiunto.</div>';
    }
    html += '<div class="assign-manuale"><label>Oppure scegliete voi giorno e orario</label>' +
            '<div class="dayrow" id="assign-dayrow"></div>' +
            '<input type="time" id="assign-time" value="09:00">' +
            '<button class="btn primary" id="assign-manuale-conferma" style="width:100%;">Aggiungi comunque</button></div>';
    body.innerHTML = html;

    body.querySelectorAll(".assign-opt").forEach(function (btn) {
      btn.addEventListener("click", function () {
        pianificaPreferenza(fav, this.dataset.day, this.dataset.dopo || null);
      });
    });

    var dayrowEl = document.getElementById("assign-dayrow");
    var scelto = DAYS.length ? DAYS[0].id : null;
    DAYS.forEach(function (d) {
      var pill = document.createElement("div");
      pill.className = "daypill" + (d.id === scelto ? " active" : "");
      pill.innerHTML = '<div class="dw">' + weekdayShort(d.date) + '</div><div class="dn num">' + dayNum(d.date) + "</div>";
      pill.addEventListener("click", function () {
        scelto = d.id;
        dayrowEl.querySelectorAll(".daypill").forEach(function (p) { p.classList.remove("active"); });
        pill.classList.add("active");
      });
      dayrowEl.appendChild(pill);
    });
    document.getElementById("assign-manuale-conferma").addEventListener("click", function () {
      if (!scelto) { toast("Non ci sono giorni nel viaggio"); return; }
      var ora = document.getElementById("assign-time").value || "09:00";
      confermaPreferenza(fav, scelto, ora);
    });
  }

  // Posizione consigliata da giorniAlternativi: subito dopo "dopoDi", oppure
  // un'ora prima della prima tappa se va messa in testa al giorno.
  function pianificaPreferenza(fav, dayId, dopoTitolo) {
    var dest = stopsForDay(dayId);
    var nuovaOra = "09:00";
    if (dopoTitolo) {
      var rif = dest.find(function (x) { return x.title === dopoTitolo; });
      if (rif) {
        var m = window.Giornata.min(rif.time) + (rif.dur || 0) + 15;
        nuovaOra = window.Giornata.hhmm(m).replace("+1", "");
      }
    } else if (dest.length) {
      nuovaOra = window.Giornata.hhmm(Math.max(0, window.Giornata.min(dest[0].time) - 60));
    }
    confermaPreferenza(fav, dayId, nuovaOra);
  }

  function confermaPreferenza(fav, dayId, time) {
    var newId = "custom-" + Date.now();
    var nuovaTappa = {
      id: newId, title: fav.title, sub: fav.sub || "", cat: fav.cat || "experience",
      prio: fav.prio || "norm", notes: fav.notes || "", dur: fav.dur || 45, tmin: 0, tmode: "walk",
      day: dayId, time: time, done: false,
      q: fav.title + " " + (fav.sub || "")
    };
    // di nuovo: lat/lon/foto entrano nel payload solo se esistono davvero.
    if (fav.lat != null) { nuovaTappa.lat = fav.lat; nuovaTappa.lon = fav.lon; }
    if (fav.foto) nuovaTappa.foto = fav.foto;
    state.custom.push(nuovaTappa);
    state.favorites = state.favorites.filter(function (f) { return f.id !== fav.id; });
    closeAssignSheet();
    persist();
    toast("Aggiunto all'itinerario del " + ((dayById(dayId) || {}).date || ""));

    // Da qui in poi è una tappa come tutte le altre: entra nell'elenco del
    // giorno all'orario scelto, prende il suo numero e compare sulla mappa.
    // Se il preferito non aveva una posizione, la cerchiamo adesso — altrimenti
    // sarebbe l'unica tappa senza pin.
    if (nuovaTappa.lat == null) {
      trovaCoordinate(nuovaTappa.title, nuovaTappa.sub).then(function (c) {
        if (c) applicaPatchTappa(newId, { lat: c.lat, lon: c.lon });
      });
    }
  }

  /* ---------- Prenotazioni (tab Altro) ----------
     Codici, orari e indirizzi che servono al banco del check-in o davanti a un
     tassista: spesso senza rete e sempre di fretta. Per questo il codice è
     grande, in carattere a larghezza fissa (si legge a voce senza sbagliare
     una O per uno 0) e si copia con un tocco. */
  function prenTipo(id) {
    return PREN_TIPI.find(function (t) { return t.id === id; }) || PREN_TIPI[4];
  }

  function quandoLeggibile(p) {
    if (!p.data) return p.ora || "";
    var d = new Date(p.data + "T00:00:00");
    var mesi = ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"];
    return weekdayShort(p.data) + " " + d.getDate() + " " + mesi[d.getMonth()] + (p.ora ? " · " + p.ora : "");
  }

  function renderPrenotazioni() {
    var el = document.getElementById("pren-lista");
    if (!el) return;
    el.innerHTML = "";
    if (!state.bookings.length) {
      el.innerHTML = '<div class="pren-vuoto">Nessuna prenotazione salvata.<br>Voli, hotel, treni: quello che serve avere sottomano anche senza rete.</div>';
      return;
    }
    // in ordine di quando servono, non di quando sono state inserite
    var ordinate = state.bookings.slice().sort(function (a, b) {
      return ((a.data || "9999") + (a.ora || "")).localeCompare((b.data || "9999") + (b.ora || ""));
    });
    ordinate.forEach(function (p) {
      var t = prenTipo(p.tipo);
      var card = document.createElement("div");
      card.className = "pren-card";
      card.innerHTML =
        '<div class="pren-ico ' + t.id + '"><svg><use href="#' + t.icon + '"/></svg></div>' +
        '<div class="pren-corpo">' +
        '<div class="pren-nome">' + escapeHtml(p.nome || t.label) + "</div>" +
        (quandoLeggibile(p) ? '<div class="pren-quando">' + quandoLeggibile(p) + "</div>" : "") +
        (p.codice ? '<div class="pren-codice"><svg><use href="#ic-copy"/></svg>' + escapeHtml(p.codice) + "</div>" : "") +
        (p.dove ? '<div class="pren-dove">' + escapeHtml(p.dove) + "</div>" : "") +
        (p.indirizzo ? '<div class="pren-dove">' + escapeHtml(p.indirizzo) + "</div>" : "") +
        "</div>";
      card.addEventListener("click", function () { openPrenSheet(p.id); });
      var cod = card.querySelector(".pren-codice");
      if (cod) cod.addEventListener("click", function (e) {
        e.stopPropagation();
        try {
          navigator.clipboard.writeText(p.codice);
          toast("Codice copiato");
        } catch (err) { toast("Copia non riuscita"); }
      });
      el.appendChild(card);
    });
  }

  /* ---------- foglio prenotazione ---------- */
  var prenSheet = document.getElementById("pren-sheet");
  var prenInModifica = null;
  buildPickrow("pren-tipo", PREN_TIPI);

  function openPrenSheet(id) {
    prenInModifica = id || null;
    var p = id ? state.bookings.find(function (x) { return x.id === id; }) : null;
    document.getElementById("pren-titolo").textContent = p ? "Modifica prenotazione" : "Nuova prenotazione";
    selectPick("pren-tipo", p ? p.tipo : "volo");
    document.getElementById("pren-nome").value = p ? p.nome || "" : "";
    document.getElementById("pren-codice").value = p ? p.codice || "" : "";
    document.getElementById("pren-data").value = p ? p.data || "" : "";
    document.getElementById("pren-ora").value = p ? p.ora || "" : "";
    document.getElementById("pren-dove").value = p ? p.dove || "" : "";
    document.getElementById("pren-indirizzo").value = p ? p.indirizzo || "" : "";
    document.getElementById("pren-note").value = p ? p.note || "" : "";
    document.getElementById("pren-elimina").style.display = p ? "block" : "none";
    prenSheet.style.transform = "";
    backdrop.classList.add("show");
    prenSheet.classList.add("show");
    bloccaSfondo(true);
  }
  function closePrenSheet() {
    backdrop.classList.remove("show");
    prenSheet.classList.remove("show");
    bloccaSfondo(false);
    prenInModifica = null;
  }
  document.getElementById("pren-close").addEventListener("click", closePrenSheet);
  backdrop.addEventListener("click", closePrenSheet);
  document.getElementById("btn-add-pren").addEventListener("click", function () { openPrenSheet(null); });

  document.getElementById("pren-salva").addEventListener("click", function () {
    var nome = document.getElementById("pren-nome").value.trim();
    if (!nome) { toast("Serve almeno di cosa si tratta"); return; }
    // ogni campo ha sempre un valore: Firestore rifiuta undefined
    var dati = {
      tipo: getPick("pren-tipo") || "altro",
      nome: nome,
      codice: document.getElementById("pren-codice").value.trim(),
      data: document.getElementById("pren-data").value || "",
      ora: document.getElementById("pren-ora").value || "",
      dove: document.getElementById("pren-dove").value.trim(),
      indirizzo: document.getElementById("pren-indirizzo").value.trim(),
      note: document.getElementById("pren-note").value.trim(),
    };
    if (prenInModifica) {
      state.bookings = state.bookings.map(function (x) {
        return x.id === prenInModifica ? Object.assign({}, x, dati) : x;
      });
      toast("Prenotazione aggiornata");
    } else {
      dati.id = "pren-" + Date.now();
      dati.createdAt = Date.now();
      state.bookings.push(dati);
      toast("Prenotazione salvata");
    }
    closePrenSheet();
    persist();
  });

  document.getElementById("pren-elimina").addEventListener("click", function () {
    if (!prenInModifica) return;
    state.bookings = state.bookings.filter(function (x) { return x.id !== prenInModifica; });
    toast("Prenotazione eliminata");
    closePrenSheet();
    persist();
  });

  document.getElementById("riga-esci").addEventListener("click", esciDavvero);

  /* ---------- ricerca ----------
     Le lenti d'ingrandimento nelle intestazioni prima erano decorative. Con
     52 tappe su 14 giorni la domanda vera è "dove l'avevamo messo, Nishiki
     Market?", e la risposta non deve costare quattordici tocchi sul
     calendario. Cerca in una volta sola fra tappe, preferiti e prenotazioni,
     e portarsi dove sta la cosa trovata. */
  var cercaSheet = document.getElementById("cerca-sheet");

  function normalizza(t) {
    return String(t || "").toLowerCase();
  }

  function cercaOvunque(q) {
    var t = normalizza(q);
    if (t.length < 2) return null;
    var dentro = function (s) { return normalizza(s).indexOf(t) !== -1; };
    return {
      tappe: allStops().filter(function (s) {
        return dentro(s.title) || dentro(s.sub) || dentro(s.notes);
      }).slice(0, 12),
      preferiti: state.favorites.filter(function (f) {
        return dentro(f.title) || dentro(f.sub) || dentro(f.notes);
      }).slice(0, 8),
      prenotazioni: state.bookings.filter(function (p) {
        return dentro(p.nome) || dentro(p.codice) || dentro(p.dove) || dentro(p.note);
      }).slice(0, 8),
    };
  }

  function renderRicerca() {
    var box = document.getElementById("cerca-esiti");
    var esiti = cercaOvunque(document.getElementById("cerca-tutto").value);
    box.innerHTML = "";
    if (!esiti) {
      box.innerHTML = '<div class="cerca-vuoto">Scrivete almeno due lettere.<br>Cerca fra le tappe di tutti i giorni, i preferiti e le prenotazioni.</div>';
      return;
    }
    var quanti = esiti.tappe.length + esiti.preferiti.length + esiti.prenotazioni.length;
    if (!quanti) {
      box.innerHTML = '<div class="cerca-vuoto">Nessun risultato.</div>';
      return;
    }

    function riga(icona, titolo, sotto, onTap) {
      var el = document.createElement("div");
      el.className = "cerca-esito";
      el.innerHTML =
        '<div class="ce-ico"' + (icona.foto ? ' style="background-image:url(\'' + icona.foto + '\')"' : "") + ">" +
        (icona.foto ? "" : '<svg><use href="#' + icona.svg + '"/></svg>') + "</div>" +
        '<div class="ce-corpo"><div class="ce-t">' + escapeHtml(titolo) + "</div>" +
        '<div class="ce-s">' + escapeHtml(sotto) + "</div></div>";
      el.addEventListener("click", onTap);
      box.appendChild(el);
    }
    function gruppo(nome) {
      var g = document.createElement("div");
      g.className = "cerca-gruppo";
      g.textContent = nome;
      box.appendChild(g);
    }

    if (esiti.tappe.length) {
      gruppo("Tappe");
      esiti.tappe.forEach(function (s) {
        var g = dayById(s.day);
        riga({ foto: imgFor(s) }, s.title,
          (g ? weekdayShort(g.date) + " " + dayNum(g.date) + " · " + g.city + " · " : "") + s.time,
          function () {
            chiudiRicerca();
            if (s.day) selectedDay.itinerario = s.day;
            switchView("itinerario");
            renderAll();
            setTimeout(function () { openSheet(s.id); }, 220);
          });
      });
    }
    if (esiti.preferiti.length) {
      gruppo("Preferiti");
      esiti.preferiti.forEach(function (f) {
        riga({ foto: imgFor(f) }, f.title, f.sub || "da programmare", function () {
          chiudiRicerca();
          switchView("preferiti");
        });
      });
    }
    if (esiti.prenotazioni.length) {
      gruppo("Prenotazioni");
      esiti.prenotazioni.forEach(function (p) {
        riga({ svg: prenTipo(p.tipo).icon }, p.nome,
          [quandoLeggibile(p), p.codice].filter(Boolean).join(" · "),
          function () {
            chiudiRicerca();
            switchView("altro");
            setTimeout(function () { openPrenSheet(p.id); }, 220);
          });
      });
    }
  }

  function apriRicerca() {
    document.getElementById("cerca-tutto").value = "";
    renderRicerca();
    cercaSheet.style.transform = "";
    backdrop.classList.add("show");
    cercaSheet.classList.add("show");
    bloccaSfondo(true);
    // la tastiera si apre da sola: qui si cerca, non si guarda
    setTimeout(function () { document.getElementById("cerca-tutto").focus(); }, 320);
  }
  function chiudiRicerca() {
    backdrop.classList.remove("show");
    cercaSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("cerca-close").addEventListener("click", chiudiRicerca);
  backdrop.addEventListener("click", chiudiRicerca);
  document.getElementById("cerca-tutto").addEventListener("input", renderRicerca);
  document.querySelectorAll(".cerca-apri").forEach(function (b) {
    b.addEventListener("click", apriRicerca);
  });

  /* ---------- idee per città ----------
     Il pezzo che mancava fra "che si fa questo pomeriggio?" e il piano. Nel
     piano ci sono già i posti grossi; qui ci sono gli altri, controllati uno
     per uno su fonti vere (js/idee.js). Un tocco e l'idea diventa un
     preferito: da lì "Pianifica" la mette nel giorno dove ci sta davvero,
     con la stessa strada già collaudata. Nessuna scorciatoia nuova. */
  var ideeSheet = document.getElementById("idee-sheet");
  var ideaCitta = null;

  function cittaDelViaggio() {
    // Le città nell'ordine in cui si incontrano, non in ordine alfabetico: la
    // prima pillola è dove si è, non dove capita.
    var viste = [];
    DAYS.forEach(function (d) {
      (window.TRAVI_IDEE || []).forEach(function (g) {
        if (d.city.indexOf(g.citta) !== -1 && viste.indexOf(g.citta) === -1) viste.push(g.citta);
      });
    });
    (window.TRAVI_IDEE || []).forEach(function (g) {
      if (viste.indexOf(g.citta) === -1) viste.push(g.citta);
    });
    return viste;
  }
  function cittaDiOggi() {
    var d = DAYS.find(function (x) { return x.id === defaultDay(); });
    var lista = cittaDelViaggio();
    var trovata = d && lista.find(function (c) { return d.city.indexOf(c) !== -1; });
    return trovata || lista[0];
  }
  function gruppoIdee(citta) {
    return (window.TRAVI_IDEE || []).find(function (g) { return g.citta === citta; });
  }
  function giaPreferito(idea) {
    return state.favorites.some(function (f) { return normalizza(f.title) === normalizza(idea.titolo); });
  }
  function salvaIdea(idea) {
    if (giaPreferito(idea)) { toast("Già nei preferiti"); return; }
    var fav = {
      id: "fav-" + Date.now(),
      title: idea.titolo,
      sub: idea.zona,
      cat: "experience",
      prio: "norm",
      notes: [idea.perche, idea.quando, idea.nota].filter(Boolean).join("\n"),
      createdAt: Date.now(),
      lat: idea.lat, lon: idea.lon,
      dur: idea.durata,
    };
    state.favorites.push(fav);
    persist();
    renderIdee();
    toast("Aggiunto ai preferiti");
    // La foto arriva dopo, come per ogni preferito scritto a mano.
    if (window.TraviFoto) {
      window.TraviFoto.cerca(idea.titolo + " " + idea.zona).then(function (url) {
        if (!url) return;
        state.favorites = state.favorites.map(function (f) {
          return f.id === fav.id ? Object.assign({}, f, { foto: url }) : f;
        });
        persist();
      });
    }
  }
  function renderIdee() {
    var pillole = document.getElementById("idee-citta");
    var box = document.getElementById("idee-lista");
    pillole.innerHTML = "";
    box.innerHTML = "";
    cittaDelViaggio().forEach(function (c) {
      var p = document.createElement("div");
      p.className = "pick" + (c === ideaCitta ? " sel" : "");
      p.textContent = c;
      p.addEventListener("click", function () { ideaCitta = c; renderIdee(); });
      pillole.appendChild(p);
    });
    var g = gruppoIdee(ideaCitta);
    if (!g) return;
    if (g.nota) {
      var av = document.createElement("div");
      av.className = "idee-avviso";
      av.textContent = g.nota;
      box.appendChild(av);
    }
    g.voci.forEach(function (idea) {
      var gia = giaPreferito(idea);
      var el = document.createElement("div");
      el.className = "idea" + (gia ? " gia" : "");
      el.innerHTML =
        '<div class="i-testa"><div><div class="i-t">' + escapeHtml(idea.titolo) + "</div>" +
        '<div class="i-z">' + escapeHtml(idea.zona) + "</div></div>" +
        '<div class="idea-salva"><svg><use href="#' + (gia ? "ic-check" : "ic-heart") + '"/></svg></div></div>' +
        '<div class="i-p">' + escapeHtml(idea.perche) + "</div>" +
        '<div class="i-meta"><div class="i-tag">' + escapeHtml(idea.quando) + "</div>" +
        '<div class="i-tag">' + idea.durata + " min</div></div>" +
        (idea.nota ? '<div class="i-nota">' + escapeHtml(idea.nota) + "</div>" : "");
      el.querySelector(".idea-salva").addEventListener("click", function () { salvaIdea(idea); });
      box.appendChild(el);
    });
  }
  function apriIdee() {
    ideaCitta = ideaCitta || cittaDiOggi();
    renderIdee();
    ideeSheet.style.transform = "";
    backdrop.classList.add("show");
    ideeSheet.classList.add("show");
    bloccaSfondo(true);
  }
  function chiudiIdee() {
    backdrop.classList.remove("show");
    ideeSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("idee-close").addEventListener("click", chiudiIdee);
  backdrop.addEventListener("click", chiudiIdee);
  document.getElementById("btn-idee").addEventListener("click", apriIdee);

  /* ---------- frasi in giapponese ----------
     Tutto dentro l'app, niente traduttore: nella metropolitana di Tokyo non
     c'è campo e al banco di un izakaya non si ha il tempo di aspettare che
     un'app carichi. La riga in giapponese è grande perché il gesto vero è
     girare lo schermo verso l'altra persona. */
  var frasiSheet = document.getElementById("frasi-sheet");

  function renderFrasi() {
    var box = document.getElementById("frasi-lista");
    var q = normalizza(document.getElementById("frasi-cerca").value);
    var gruppi = window.TRAVI_FRASI || [];
    box.innerHTML = "";
    var trovate = 0;
    gruppi.forEach(function (g) {
      var voci = q.length < 2 ? g.voci : g.voci.filter(function (v) {
        return normalizza(v.it).indexOf(q) !== -1 || normalizza(v.ro).indexOf(q) !== -1;
      });
      if (!voci.length) return;
      trovate += voci.length;
      var t = document.createElement("div");
      t.className = "frase-gruppo";
      t.textContent = g.gruppo;
      box.appendChild(t);
      if (g.nota && q.length < 2) {
        var n = document.createElement("div");
        n.className = "frase-nota";
        n.textContent = g.nota;
        box.appendChild(n);
      }
      voci.forEach(function (v) {
        var el = document.createElement("div");
        el.className = "frase";
        el.innerHTML =
          '<div class="f-ja">' + escapeHtml(v.ja) + "</div>" +
          '<div class="f-ro">' + escapeHtml(v.ro) + "</div>" +
          '<div class="f-it">' + escapeHtml(v.it) + "</div>";
        box.appendChild(el);
      });
    });
    if (!trovate) box.innerHTML = '<div class="cerca-vuoto">Nessuna frase con questa parola.</div>';
  }

  function apriFrasi() {
    document.getElementById("frasi-cerca").value = "";
    renderFrasi();
    frasiSheet.style.transform = "";
    backdrop.classList.add("show");
    frasiSheet.classList.add("show");
    bloccaSfondo(true);
  }
  function chiudiFrasi() {
    backdrop.classList.remove("show");
    frasiSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("frasi-close").addEventListener("click", chiudiFrasi);
  backdrop.addEventListener("click", chiudiFrasi);
  document.getElementById("frasi-cerca").addEventListener("input", renderFrasi);
  document.getElementById("riga-frasi").addEventListener("click", apriFrasi);

  /* ---------- yen ed euro ----------
     Il cambio si scarica quando c'è rete e si tiene da parte: in Giappone
     serve davanti a un menù, cioè quasi sempre senza rete. Il valore di
     partenza qui sotto è quello del 7 settembre 2026, così anche il primo
     avvio offline dà un numero sensato invece di un trattino. */
  var CAMBIO_DI_SCORTA = { eurJpy: 181.5, quando: "2026-09-07" };
  var cambioSheet = document.getElementById("cambio-sheet");

  function leggiCambio() {
    try {
      var c = JSON.parse(localStorage.getItem("travi-cambio") || "null");
      if (c && c.eurJpy > 0) return c;
    } catch (e) {}
    return CAMBIO_DI_SCORTA;
  }
  function aggiornaCambio() {
    if (!navigator.onLine) return Promise.resolve(leggiCambio());
    return fetch("https://api.frankfurter.dev/v1/latest?base=EUR&symbols=JPY")
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var v = d && d.rates && d.rates.JPY;
        if (!(v > 0)) throw new Error("niente");
        var c = { eurJpy: v, quando: d.date || todayISO() };
        try { localStorage.setItem("travi-cambio", JSON.stringify(c)); } catch (e) {}
        return c;
      })
      .catch(function () { return leggiCambio(); });
  }
  function dataLeggibile(iso) {
    if (!iso) return "";
    var p = String(iso).split("-");
    return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : iso;
  }
  function euroDaYen(y) { return y / leggiCambio().eurJpy; }
  function formattaEuro(n) {
    return n.toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function formattaYen(n) {
    return Math.round(n).toLocaleString("it-IT");
  }
  function soloNumero(t) {
    var pulito = String(t || "").replace(/[^0-9.,]/g, "").replace(/\./g, "").replace(",", ".");
    var n = parseFloat(pulito);
    return isNaN(n) ? null : n;
  }
  function renderScalaCambio() {
    var box = document.getElementById("cambio-scala");
    if (!box) return;
    box.innerHTML = "";
    [100, 500, 1000, 3000, 5000, 10000].forEach(function (y) {
      var r = document.createElement("div");
      r.className = "cambio-scala-riga";
      r.innerHTML = "<span>" + formattaYen(y) + " ¥</span><span>" + formattaEuro(euroDaYen(y)) + " €</span>";
      box.appendChild(r);
    });
    var c = leggiCambio();
    document.getElementById("cambio-nota").textContent =
      "1 € = " + c.eurJpy.toFixed(2) + " ¥ · aggiornato il " + dataLeggibile(c.quando);
  }
  function aggiornaRigaCambio() {
    var el = document.getElementById("rm-cambio-sub");
    if (el) el.textContent = "1 € = " + leggiCambio().eurJpy.toFixed(2) + " ¥";
  }
  var jpyEl = document.getElementById("cambio-jpy");
  var eurEl = document.getElementById("cambio-eur");
  jpyEl.addEventListener("input", function () {
    var n = soloNumero(jpyEl.value);
    eurEl.value = n == null ? "" : formattaEuro(euroDaYen(n));
  });
  eurEl.addEventListener("input", function () {
    var n = soloNumero(eurEl.value);
    jpyEl.value = n == null ? "" : formattaYen(n * leggiCambio().eurJpy);
  });
  function apriCambio() {
    jpyEl.value = ""; eurEl.value = "";
    renderScalaCambio();
    cambioSheet.style.transform = "";
    backdrop.classList.add("show");
    cambioSheet.classList.add("show");
    bloccaSfondo(true);
    aggiornaCambio().then(function () { renderScalaCambio(); aggiornaRigaCambio(); });
  }
  function chiudiCambio() {
    backdrop.classList.remove("show");
    cambioSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("cambio-close").addEventListener("click", chiudiCambio);
  backdrop.addEventListener("click", chiudiCambio);
  document.getElementById("riga-cambio").addEventListener("click", apriCambio);

  /* ---------- diario ----------
     Quattordici righe, una per giorno, e si apre solo quella che si tocca.
     Si salva da solo mentre si scrive: di sera, stanchi, nessuno cerca il
     tasto Salva. Solo testo: le foto stanno già nel rullino del telefono. */
  var VOTI = [
    { id: "bella", label: "Bella" },
    { id: "bellissima", label: "Bellissima" },
    { id: "da-ricordare", label: "Da ricordare" },
  ];
  var diarioSheet = document.getElementById("diario-sheet");
  var salvaDiarioTimer = null;

  function vociDiario() {
    return Object.keys(state.diario).filter(function (k) {
      return state.diario[k] && (state.diario[k].t || "").trim();
    });
  }
  function aggiornaRigaDiario() {
    var el = document.getElementById("rm-diario-sub");
    if (!el) return;
    var n = vociDiario().length;
    el.textContent = n === 0 ? "Ancora niente scritto"
      : n === 1 ? "Una giornata scritta" : n + " giornate scritte";
  }
  function salvaDiarioFraPoco() {
    clearTimeout(salvaDiarioTimer);
    salvaDiarioTimer = setTimeout(function () {
      persist();
      aggiornaRigaDiario();
    }, 700);
  }
  function renderDiario() {
    var box = document.getElementById("diario-body");
    box.innerHTML = "";
    DAYS.forEach(function (d) {
      var voce = state.diario[d.id] || {};
      var scritto = !!(voce.t || "").trim();
      var el = document.createElement("div");
      el.className = "dia-giorno" + (scritto ? " scritto" : "");
      el.innerHTML =
        '<div class="dia-testa">' +
          '<div class="dia-data"><div class="dd-n">' + dayNum(d.date) + '</div><div class="dd-g">' + weekdayShort(d.date) + "</div></div>" +
          '<div class="dia-corpo"><div class="dia-t">' + escapeHtml(d.city) + "</div>" +
          '<div class="dia-s">' + escapeHtml(scritto ? voce.t.trim().replace(/\s+/g, " ") : d.theme) + "</div></div>" +
          '<svg class="dia-apri" width="18" height="18"><use href="#ic-chev"/></svg>' +
        "</div>" +
        '<div class="dia-editor">' +
          '<textarea placeholder="Cosa è successo oggi…"></textarea>' +
          '<div class="dia-voti"></div>' +
        "</div>";
      var ta = el.querySelector("textarea");
      ta.value = voce.t || "";
      ta.addEventListener("input", function () {
        state.diario[d.id] = Object.assign({}, state.diario[d.id], { t: ta.value });
        el.classList.toggle("scritto", !!ta.value.trim());
        el.querySelector(".dia-s").textContent = ta.value.trim() ? ta.value.trim().replace(/\s+/g, " ") : d.theme;
        salvaDiarioFraPoco();
      });
      var voti = el.querySelector(".dia-voti");
      VOTI.forEach(function (v) {
        var p = document.createElement("div");
        p.className = "pick" + (voce.v === v.id ? " sel" : "");
        p.textContent = v.label;
        p.addEventListener("click", function () {
          var attuale = (state.diario[d.id] || {}).v;
          var nuovo = attuale === v.id ? null : v.id;
          state.diario[d.id] = Object.assign({}, state.diario[d.id], { v: nuovo, t: ta.value });
          voti.querySelectorAll(".pick").forEach(function (x) { x.classList.remove("sel"); });
          if (nuovo) p.classList.add("sel");
          salvaDiarioFraPoco();
        });
        voti.appendChild(p);
      });
      el.querySelector(".dia-testa").addEventListener("click", function () {
        var era = el.classList.contains("aperto");
        box.querySelectorAll(".dia-giorno").forEach(function (x) { x.classList.remove("aperto"); });
        if (!era) { el.classList.add("aperto"); setTimeout(function () { ta.focus(); }, 120); }
      });
      box.appendChild(el);
    });
  }
  function apriDiario() {
    renderDiario();
    diarioSheet.style.transform = "";
    backdrop.classList.add("show");
    diarioSheet.classList.add("show");
    bloccaSfondo(true);
    // il giorno di oggi è quello che si vuole scrivere: si apre da solo
    var oggi = defaultDay();
    var indice = DAYS.findIndex(function (d) { return d.id === oggi; });
    if (indice >= 0) {
      var riga = document.getElementById("diario-body").children[indice];
      if (riga) { riga.classList.add("aperto"); riga.scrollIntoView({ block: "center" }); }
    }
  }
  function chiudiDiario() {
    clearTimeout(salvaDiarioTimer);
    persist();
    aggiornaRigaDiario();
    backdrop.classList.remove("show");
    diarioSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("diario-close").addEventListener("click", chiudiDiario);
  backdrop.addEventListener("click", chiudiDiario);
  document.getElementById("riga-diario").addEventListener("click", apriDiario);

  /* ---------- foglio budget extra ---------- */
  var budgetSheet = document.getElementById("budget-sheet");
  var bgWhoEl = document.getElementById("bg-who");
  BUDGET_WHO.forEach(function (w, i) {
    var p = document.createElement("div");
    p.className = "pick" + (i === 2 ? " sel" : "");
    p.dataset.id = w.id;
    p.textContent = w.label;
    p.addEventListener("click", function () {
      bgWhoEl.querySelectorAll(".pick").forEach(function (x) { x.classList.remove("sel"); });
      p.classList.add("sel");
    });
    bgWhoEl.appendChild(p);
  });
  function openBudgetSheet() {
    budgetSheet.style.transform = "";
    backdrop.classList.add("show");
    budgetSheet.classList.add("show");
    bloccaSfondo(true);
  }
  function closeBudgetSheet() {
    backdrop.classList.remove("show");
    budgetSheet.classList.remove("show");
    bloccaSfondo(false);
  }
  document.getElementById("budget-summary-card").addEventListener("click", openBudgetSheet);
  document.getElementById("riga-budget").addEventListener("click", openBudgetSheet);
  document.getElementById("budget-close").addEventListener("click", closeBudgetSheet);
  backdrop.addEventListener("click", closeBudgetSheet);
  document.getElementById("btn-budget-add").addEventListener("click", function () {
    var title = document.getElementById("bg-title").value.trim();
    var amount = parseFloat(document.getElementById("bg-amount").value);
    if (!title) { toast("Serve una descrizione della spesa"); return; }
    if (!amount || amount <= 0) { toast("Inserite un importo valido"); return; }
    var who = bgWhoEl.querySelector(".pick.sel");
    state.budget.push({
      id: "b" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      title: title,
      amount: amount,
      who: who ? who.dataset.id : "insieme",
      createdAt: Date.now(),
    });
    document.getElementById("bg-title").value = "";
    document.getElementById("bg-amount").value = "";
    persist();
    toast("Spesa aggiunta");
  });

  document.getElementById("btn-save").addEventListener("click", function () {
    var title = document.getElementById("f-title").value.trim();
    if (!title) { toast("Serve almeno un titolo"); return; }
    var payload = {
      title: title,
      sub: document.getElementById("f-sub").value.trim(),
      time: document.getElementById("f-time").value || "09:00",
      dur: parseInt(getPick("f-duration-chips"), 10) || 30,
      tmin: parseInt(document.getElementById("f-travel").value, 10) || 0,
      notes: document.getElementById("f-notes").value.trim(),
      cat: getPick("f-category") || "experience",
      tmode: getPick("f-transport") || "walk",
      prio: getPick("f-priorita") || "norm",
      done: document.getElementById("f-done").classList.contains("on"),
    };
    // undefined non è un valore che Firestore accetta: questi due campi
    // esistono nel payload SOLO quando c'è davvero un valore da mettere.
    if (sheetLatLon) { payload.lat = sheetLatLon.lat; payload.lon = sheetLatLon.lon; }
    if (sheetExistingFoto) payload.foto = sheetExistingFoto;

    var idPerFoto;
    if (editingId) {
      idPerFoto = editingId;
      var isCustom = state.custom.some(function (c) { return c.id === editingId; });
      if (isCustom) {
        state.custom = state.custom.map(function (c) { return c.id === editingId ? Object.assign({}, c, payload) : c; });
      } else {
        state.overrides[editingId] = Object.assign({}, state.overrides[editingId] || {}, payload);
      }
      toast("Tappa aggiornata");
    } else {
      var newId = "custom-" + Date.now();
      payload.id = newId;
      payload.day = selectedDay.itinerario;
      payload.q = payload.title + " " + payload.sub;
      state.custom.push(payload);
      idPerFoto = newId;
      toast("Tappa aggiunta");
    }
    closeSheet();
    persist();

    // Nessuna foto già presente: la si cerca in background (vedi js/foto.js),
    // il salvataggio non aspetta la rete. Vale sia per una tappa scritta a
    // mano sia per una scelta dalla ricerca senza una foto trovata prima.
    if (!payload.foto && window.TraviFoto) {
      window.TraviFoto.cerca(payload.title + " " + payload.sub).then(function (url) {
        if (url) applicaPatchTappa(idPerFoto, { foto: url });
      });
    }

    // Senza coordinate non c'è nessun pin sulla mappa: se non sono arrivate
    // dalla ricerca del posto, le cerchiamo dal nome in background. È così che
    // una tappa scritta a mano prende comunque il suo numero sulla mappa.
    if (payload.lat == null) {
      trovaCoordinate(payload.title, payload.sub).then(function (c) {
        if (c) applicaPatchTappa(idPerFoto, { lat: c.lat, lon: c.lon });
      });
    }
  });

  document.getElementById("btn-delete").addEventListener("click", function () {
    if (!editingId) return;
    var current = allStops().find(function (x) { return x.id === editingId; });
    if (current && current.locked) { toast("Questa tappa è bloccata: non può essere eliminata in questa fase."); return; }
    var isCustom = state.custom.some(function (c) { return c.id === editingId; });
    if (isCustom) { state.custom = state.custom.filter(function (c) { return c.id !== editingId; }); }
    else { state.removed.push(editingId); }
    toast("Tappa eliminata");
    closeSheet();
    persist();
  });

  document.getElementById("btn-add-stop").addEventListener("click", function () { openSheet(null); });
  // fab-add: il suo click handler viene assegnato da switchView() (apre la
  // tappa o il preferito a seconda della vista attiva), non qui.

  /* ---------- recalc day ---------- */
  document.getElementById("btn-recalc").addEventListener("click", function () {
    var list = stopsForDay(selectedDay.itinerario);
    var firstPendingIdx = list.findIndex(function (s) { return !s.done; });
    if (firstPendingIdx === -1) { toast("Tutte le tappe di oggi sono completate"); return; }
    var isToday = todayISO() === dayById(selectedDay.itinerario).date;
    var now = new Date();
    var cursor = isToday ? now.getHours() * 60 + now.getMinutes() + 5 : timeToMin(list[firstPendingIdx].time);
    for (var i = firstPendingIdx; i < list.length; i++) {
      var s = list[i];
      var newTime = minToTime(cursor);
      var isCustom = state.custom.some(function (c) { return c.id === s.id; });
      if (isCustom) { state.custom = state.custom.map(function (c) { return c.id === s.id ? Object.assign({}, c, { time: newTime }) : c; }); }
      else { state.overrides[s.id] = Object.assign({}, state.overrides[s.id] || {}, { time: newTime }); }
      cursor += (s.dur || 30) + (s.tmin || 0);
    }
    toast("Giornata ricalcolata");
    persist();
  });

  // Tutti i fogli dell'app si chiudono col trascinamento verso il basso, non
  // solo con la ✕ in alto a destra.
  rendiTrascinabile(sheet, closeSheet);
  rendiTrascinabile(favSheet, closeFavSheet);
  rendiTrascinabile(assignSheet, closeAssignSheet);
  rendiTrascinabile(budgetSheet, closeBudgetSheet);
  rendiTrascinabile(prenSheet, closePrenSheet);
  rendiTrascinabile(cercaSheet, chiudiRicerca);
  rendiTrascinabile(ideeSheet, chiudiIdee);
  rendiTrascinabile(frasiSheet, chiudiFrasi);
  rendiTrascinabile(cambioSheet, chiudiCambio);
  rendiTrascinabile(diarioSheet, chiudiDiario);

  /* ---------- toast ---------- */
  var toastTimer = null;
  function toast(msg) {
    var el = document.getElementById("toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("show"); }, 2200);
  }

  /* La registrazione del service worker NON sta più qui: è passata in
     index.html, in uno script normale. Da qui dipendeva dal caricamento
     dell'SDK Firebase via rete — e senza rete non si registrava proprio
     quando serviva. Vedi la nota in index.html. */
})();
