window.SEED_TRIP = {
  trip: { start: "2027-05-05", end: "2027-05-18" },
  days: [
    {id:"d1",  date:"2027-05-05", city:"Roma → Tokyo",   theme:"Partenza e volo"},
    {id:"d2",  date:"2027-05-06", city:"Tokyo",          theme:"Arrivo a Ikebukuro"},
    {id:"d3",  date:"2027-05-07", city:"Tokyo",          theme:"Asakusa & Skytree con guida"},
    {id:"d4",  date:"2027-05-08", city:"Tokyo",          theme:"Giorno libero"},
    {id:"d5",  date:"2027-05-09", city:"Hakone",         theme:"Walking tour & ryokan"},
    {id:"d6",  date:"2027-05-10", city:"Kanazawa",       theme:"Vulcani & giardini"},
    {id:"d7",  date:"2027-05-11", city:"Kyoto",          theme:"Arrivo & Gion"},
    {id:"d8",  date:"2027-05-12", city:"Kyoto",          theme:"Kinkaku-ji & Arashiyama"},
    {id:"d9",  date:"2027-05-13", city:"Kyoto",          theme:"Kiyomizu, Fushimi Inari & Nara*"},
    {id:"d10", date:"2027-05-14", city:"Hiroshima",      theme:"Trasferimento & arrivo"},
    {id:"d11", date:"2027-05-15", city:"Miyajima",       theme:"Pace, guida & il torii sul mare"},
    {id:"d12", date:"2027-05-16", city:"Miyajima",       theme:"Giornata rilassata"},
    {id:"d13", date:"2027-05-17", city:"Osaka",          theme:"Dotonbori & Shinsekai"},
    {id:"d14", date:"2027-05-18", city:"Osaka → Roma",   theme:"Rientro"}
  ],
  stops: [
    // Day 1 — Partenza e volo (05/05)
    {id:"s101", img:"flight-generic", day:"d1", time:"14:55", title:"Volo AZ0792 Roma → Tokyo", sub:"Roma Fiumicino → Tokyo Haneda", cat:"transfer", dur:830, tmode:"car", tmin:0, notes:"Decollo da Fiumicino alle 14:55. È un volo lungo con arrivo il giorno dopo: conviene dormire il più possibile a bordo.", q:"Aeroporto di Roma Fiumicino", locked:true, lat:41.815391, lon:12.226485},

    // Day 2 — Arrivo a Ikebukuro (06/05)
    {id:"s201", img:"flight-generic", day:"d2", time:"10:25", title:"Atterraggio a Tokyo Haneda", sub:"Tokyo Haneda Airport", cat:"transfer", dur:30, tmode:"car", tmin:0, notes:"Ritirare in aeroporto la Welcome Suica e l'eSIM Creo Connect (20GB), già incluse ed emesse a vostro nome.", q:"Tokyo Haneda Airport", lat:35.545692, lon:139.776099},
    {id:"s202", img:"transfer-generic", day:"d2", time:"11:30", title:"Trasferimento in hotel (mezzi pubblici)", sub:"Haneda → Ikebukuro", cat:"transfer", dur:70, tmode:"metro", tmin:0, notes:"Servizio \"Sempre Insieme Transfer\": indicazioni passo-passo con i mezzi pubblici incluse nel pacchetto.", q:"Ikebukuro Station, Tokyo", lat:35.731332, lon:139.708825},
    {id:"s203", img:"hotel-generic", day:"d2", time:"14:00", title:"Check-in Sunshine City Prince Hotel", sub:"Ikebukuro, Tokyo — doppia standard non fumatori, piano 36-37", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"Solo pernottamento (room only). Camera alta, buona vista sulla città.", q:"Sunshine City Prince Hotel, Ikebukuro, Tokyo", lat:35.729537, lon:139.719391},
    {id:"s204", img:"ginza", day:"d2", time:"18:30", title:"Passeggiata serale leggera", sub:"Ikebukuro, Tokyo", cat:"experience", dur:90, tmode:"walk", tmin:10, notes:"Primo assaggio della città senza impegni: giusto il tempo di scrollarsi di dosso il volo.", q:"Ikebukuro, Tokyo", lat:35.729875, lon:139.711296},

    // Day 3 — Asakusa & Skytree con guida (07/05)
    {id:"s301", img:"senso-ji", day:"d3", time:"09:00", title:"Senso-ji", sub:"Asakusa, Tokyo", cat:"temple", dur:60, tmode:"car", tmin:30, notes:"Con l'Assistente Primavera: guida privata in italiano dalle 09:00 alle 17:00 per tutta la giornata.", q:"Senso-ji, Asakusa, Tokyo", lat:35.713403, lon:139.795526},
    {id:"s302", img:"nakamise-dori", day:"d3", time:"10:15", title:"Nakamise-dori", sub:"Asakusa, Tokyo", cat:"shopping", dur:45, tmode:"walk", tmin:10, notes:"Street food e souvenir lungo il viale del tempio.", q:"Nakamise-dori, Asakusa, Tokyo", lat:35.712521, lon:139.796517},
    {id:"s303", img:"tokyo-skytree", day:"d3", time:"11:30", title:"Tokyo Skytree", sub:"Sumida, Tokyo", cat:"view", dur:90, tmode:"metro", tmin:20, notes:"Vista a 360° su tutta Tokyo, Fuji permettendo.", q:"Tokyo Skytree, Tokyo", lat:35.710054, lon:139.810714},
    {id:"s304", img:"food-generic", day:"d3", time:"13:30", title:"Pranzo con la guida", sub:"Tokyo", cat:"food", dur:60, tmode:"walk", tmin:0, notes:"", q:"Tokyo", lat:35.67686, lon:139.763895},
    {id:"s305", img:"akihabara", day:"d3", time:"15:00", title:"Akihabara", sub:"Akihabara, Tokyo", cat:"shopping", dur:120, tmode:"metro", tmin:20, notes:"Ultima tappa del tour con l'Assistente Primavera, che si conclude qui alle 17:00.", q:"Akihabara, Tokyo", lat:35.701893, lon:139.774368},

    // Day 4 — Giorno libero (08/05)
    {id:"s401", img:"transfer-generic", day:"d4", time:"10:00", title:"Esperienza di guida JDM (stile Fast & Furious)", sub:"Da organizzare autonomamente — NON inclusa nel pacchetto Creo", cat:"experience", dur:180, tmode:"car", tmin:0, notes:"⚠️ Questa non è una prenotazione dell'agenzia: è un'idea vostra da prenotare voi stessi (circuito/noleggio). Orario puramente indicativo, da definire quando prenotate.", q:"Tokyo", lat:35.67686, lon:139.763895},
    {id:"s402", img:"ueno-park", day:"d4", time:"16:00", title:"Resto della giornata libero", sub:"Tokyo", cat:"experience", dur:120, tmode:"walk", tmin:0, notes:"Nessun impegno fissato: ottimo momento per un quartiere visto poco, o solo per riposare.", q:"Tokyo", lat:35.67686, lon:139.763895},

    // Day 5 — Walking tour & ryokan a Hakone (09/05)
    {id:"s501", img:"shibuya-crossing", day:"d5", time:"09:00", title:"Walking Tour \"a sorpresa\" con storyteller", sub:"Tokyo — regalo di Creo, quartiere a sorpresa", cat:"experience", dur:150, tmode:"walk", tmin:0, notes:"Tour a piedi in formula \"roulette\": il quartiere non è annunciato in anticipo. Durata 2-4 ore con storyteller.", q:"Tokyo", lat:35.67686, lon:139.763895},
    {id:"s502", img:"transfer-generic", day:"d5", time:"12:30", title:"Spedizione bagagli Tokyo → Kyoto", sub:"Servizio standard, consegna in 48h", cat:"transfer", dur:20, tmode:"car", tmin:0, notes:"I bagagli spediti oggi arriveranno direttamente a Kyoto (dove sarete tra qualche giorno): portate con voi solo il necessario per Hakone.", q:"Tokyo", lat:35.67686, lon:139.763895},
    {id:"s503", img:"transfer-generic", day:"d5", time:"14:00", title:"Trasferimento a Hakone (Romance Car)", sub:"Tokyo → Hakone", cat:"transfer", dur:90, tmode:"metro", tmin:0, notes:"Da qui è attivo l'Hakone Free Pass (2 giorni): trasporti locali e molti ingressi inclusi.", q:"Hakone-Yumoto Station", lat:35.233195, lon:139.103465},
    {id:"s504", img:"hotel-generic", day:"d5", time:"16:30", title:"Check-in Aura Tachibana", sub:"Hakone — ryokan, mezza pensione", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"Tempo per il bagno termale (onsen) prima di cena.", q:"Aura Tachibana, Hakone", lat:35.228759, lon:139.101173},
    {id:"s505", img:"food-generic", day:"d5", time:"18:00", title:"Cena kaiseki", sub:"Aura Tachibana, Hakone", cat:"food", dur:90, tmode:"walk", tmin:0, notes:"Cena inclusa nella mezza pensione.", q:"Hakone", lat:35.232366, lon:139.106885},

    // Day 6 — Hakone → Kanazawa (10/05)
    {id:"s601", img:"owakudani", day:"d6", time:"09:00", title:"Owakudani", sub:"Hakone", cat:"nature", dur:75, tmode:"bus", tmin:25, notes:"Valle vulcanica: assaggiate le uova nere cotte nelle sorgenti termali (Hakone Free Pass valido).", q:"Owakudani, Hakone", lat:35.247406, lon:139.024205},
    {id:"s602", img:"lake-ashi", day:"d6", time:"11:30", title:"Crociera sul Lago Ashi", sub:"Hakone", cat:"view", dur:60, tmode:"walk", tmin:10, notes:"Nelle giornate serene si vede il Fuji riflesso nel lago.", q:"Lake Ashi, Hakone", lat:35.214483, lon:139.001997},
    {id:"s603", img:"hakone-shrine", day:"d6", time:"13:00", title:"Hakone Shrine", sub:"Hakone", cat:"temple", dur:45, tmode:"walk", tmin:0, notes:"Il celebre torii rosso che emerge dall'acqua.", q:"Hakone Shrine, Hakone", lat:35.203973, lon:139.025583},
    {id:"s604", img:"transfer-generic", day:"d6", time:"15:00", title:"Trasferimento a Kanazawa (JR)", sub:"Hakone → Kanazawa", cat:"transfer", dur:180, tmode:"metro", tmin:0, notes:"", q:"Kanazawa Station", lat:36.578236, lon:136.646415},
    {id:"s605", img:"hotel-generic", day:"d6", time:"18:30", title:"Check-in Holiday Inn ANA Kanazawa Sky", sub:"Kanazawa", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"", q:"Holiday Inn ANA Kanazawa Sky", lat:36.572595, lon:136.655095},

    // Day 7 — Kanazawa → Kyoto (11/05)
    {id:"s701", img:"kenrokuen", day:"d7", time:"09:00", title:"Kenroku-en", sub:"Kanazawa", cat:"nature", dur:90, tmode:"walk", tmin:15, notes:"Uno dei tre giardini più belli del Giappone.", q:"Kenrokuen, Kanazawa", lat:36.562427, lon:136.662355},
    {id:"s702", img:"higashi-chaya", day:"d7", time:"11:00", title:"Higashi Chaya", sub:"Kanazawa", cat:"experience", dur:75, tmode:"walk", tmin:0, notes:"Quartiere storico delle case da tè.", q:"Higashi Chaya District, Kanazawa", lat:36.572556, lon:136.666676},
    {id:"s703", img:"transfer-generic", day:"d7", time:"13:30", title:"Trasferimento a Kyoto (JR)", sub:"Kanazawa → Kyoto", cat:"transfer", dur:150, tmode:"metro", tmin:0, notes:"", q:"Kyoto Station", lat:34.986447, lon:135.758677},
    {id:"s704", img:"hotel-generic", day:"d7", time:"16:30", title:"Check-in Oriental Hotel Kyoto Rokujo", sub:"Kyoto — letto king superior, colazione inclusa", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"", q:"Oriental Hotel Kyoto Rokujo", lat:34.994459, lon:135.753604},
    {id:"s705", img:"gion", day:"d7", time:"19:00", title:"Gion", sub:"Kyoto", cat:"experience", dur:90, tmode:"walk", tmin:0, notes:"Passeggiata serale nel quartiere delle geiko.", q:"Gion, Kyoto", lat:35.00469, lon:135.778403},

    // Day 8 — Kinkaku-ji & Arashiyama (12/05)
    {id:"s801", img:"kinkaku-ji", day:"d8", time:"09:00", title:"Kinkaku-ji", sub:"Kyoto", cat:"temple", dur:60, tmode:"bus", tmin:30, notes:"Il Padiglione d'Oro, meglio con luce del mattino.", q:"Kinkaku-ji, Kyoto", lat:35.039529, lon:135.729537},
    {id:"s802", img:"arashiyama-bamboo", day:"d8", time:"11:00", title:"Arashiyama Bamboo Grove", sub:"Arashiyama, Kyoto", cat:"nature", dur:60, tmode:"metro", tmin:30, notes:"", q:"Arashiyama Bamboo Grove, Kyoto", lat:35.016742, lon:135.671148},
    {id:"s803", img:"food-generic", day:"d8", time:"12:30", title:"Pranzo ad Arashiyama", sub:"Arashiyama, Kyoto", cat:"food", dur:60, tmode:"walk", tmin:0, notes:"", q:"Arashiyama, Kyoto", lat:35.009047, lon:135.674496},
    {id:"s804", img:"nishiki-market", day:"d8", time:"15:00", title:"Nishiki Market", sub:"Kyoto", cat:"food", dur:90, tmode:"bus", tmin:25, notes:"La \"cucina di Kyoto\": tanti assaggi street food.", q:"Nishiki Market, Kyoto", lat:35.005024, lon:135.76557},

    // Day 9 — Kiyomizu, Fushimi Inari & Nara* (13/05) — vedi nota sull'escursione
    {id:"s900", img:"transfer-generic", day:"d9", time:"08:00", title:"Attivazione Kansai-Hiroshima Area Pass", sub:"Pass regionale, 5 giorni", cat:"transfer", dur:15, tmode:"walk", tmin:0, notes:"Da oggi è valido il Kansai-Hiroshima Area Pass (5 giorni), usato nei prossimi spostamenti fino a Hiroshima/Miyajima.", q:"Kyoto Station", lat:34.986447, lon:135.758677},
    {id:"s901", img:"kiyomizu-dera", day:"d9", time:"08:30", title:"Kiyomizu-dera", sub:"Higashiyama, Kyoto", cat:"temple", dur:75, tmode:"walk", tmin:25, notes:"La terrazza in legno affacciata sulla città: meglio presto, prima della folla.", q:"Kiyomizu-dera, Kyoto", lat:34.994303, lon:135.784439},
    {id:"s902", img:"higashiyama-sannenzaka", day:"d9", time:"10:15", title:"Higashiyama & Sannen-zaka", sub:"Kyoto", cat:"shopping", dur:75, tmode:"walk", tmin:0, notes:"Viuzze storiche tra negozi e casette in legno.", q:"Sannenzaka, Kyoto", lat:34.996479, lon:135.781318},
    {id:"s903", img:"fushimi-inari", day:"d9", time:"13:00", title:"Fushimi Inari Taisha & Nara (Todai-ji, Kasuga Taisha)", sub:"Guida privata Assistente Primavera, 8 ore — ⚠️ DA CONFERMARE", cat:"experience", dur:480, tmode:"car", tmin:20, notes:"⚠️ Attenzione: nel preventivo ufficiale Creo (aggiornato al 21/08/2026) questa escursione risulta ancora datata 14 maggio, insieme a Nara. Abbiamo chiesto all'agenzia di spostarla al 13 maggio per liberare la mattina della partenza da Kyoto verso Hiroshima, ma la conferma NON è ancora arrivata da Ada: verificate lo stato prima di considerare questa data definitiva.", q:"Fushimi Inari Taisha, Kyoto", lat:34.967519, lon:135.77971},

    // Day 10 — Trasferimento & arrivo a Hiroshima (14/05)
    {id:"s1001", img:"transfer-generic", day:"d10", time:"08:30", title:"Checkout & spedizione bagagli", sub:"Kyoto → Osaka, servizio standard (48h)", cat:"transfer", dur:30, tmode:"walk", tmin:0, notes:"I bagagli spediti oggi arriveranno a Osaka, dove sarete tra qualche giorno.", q:"Kyoto Station", lat:34.986447, lon:135.758677},
    {id:"s1002", img:"transfer-generic", day:"d10", time:"10:00", title:"Trasferimento a Hiroshima (Shinkansen)", sub:"Kyoto → Hiroshima", cat:"transfer", dur:110, tmode:"metro", tmin:0, notes:"Con il Kansai-Hiroshima Area Pass.", q:"Hiroshima Station", lat:34.397826, lon:132.475577},
    {id:"s1003", img:"hotel-generic", day:"d10", time:"13:00", title:"Check-in Granvia Hiroshima", sub:"Hiroshima — colazione inclusa", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"", q:"Granvia Hiroshima", lat:34.399051, lon:132.475504},
    {id:"s1004", img:"peace-memorial", day:"d10", time:"15:30", title:"Pomeriggio libero", sub:"Hiroshima", cat:"experience", dur:120, tmode:"walk", tmin:0, notes:"Nessun impegno fissato: la visita guidata al Peace Memorial Park è domani mattina.", q:"Hiroshima", lat:34.391724, lon:132.451759},

    // Day 11 — Pace, guida & il torii sul mare (15/05)
    {id:"s1101", img:"peace-memorial", day:"d11", time:"09:00", title:"Peace Memorial Park & Museo", sub:"Hiroshima — guida turistica con licenza, 4 ore", cat:"experience", dur:240, tmode:"walk", tmin:0, notes:"Guida con licenza, in italiano, dalle 09:00 alle 13:00. Un luogo di raccoglimento, da vivere con calma.", q:"Hiroshima Peace Memorial Park", lat:34.393171, lon:132.452301},
    {id:"s1102", img:"transfer-generic", day:"d11", time:"13:30", title:"Traghetto per Miyajima", sub:"Hiroshima → Miyajima", cat:"transfer", dur:45, tmode:"car", tmin:0, notes:"Traghetto JR incluso nel pass regionale.", q:"Miyajima Ferry Terminal", lat:34.302095, lon:132.322247},
    {id:"s1103", img:"itsukushima", day:"d11", time:"14:30", title:"Santuario di Itsukushima", sub:"Miyajima", cat:"temple", dur:75, tmode:"walk", tmin:0, notes:"Il celebre torii \"galleggiante\": controllare l'orario di alta marea.", q:"Itsukushima Shrine, Miyajima", lat:34.294905, lon:132.318639},
    {id:"s1104", img:"hotel-generic", day:"d11", time:"17:00", title:"Check-in ryokan Iwaso", sub:"Miyajima — 10 tatami, mezza pensione — ⚠️ IN RICHIESTA", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"⚠️ Al momento della stesura del preventivo questo ryokan risultava \"in richiesta\" presso l'agenzia, non ancora confermato al 100%: verificate con Ada lo stato definitivo della prenotazione prima della partenza.", q:"Iwaso Ryokan, Miyajima", lat:34.295174, lon:132.322337},

    // Day 12 — Giornata rilassata (16/05)
    {id:"s1201", img:"miyajima-nature", day:"d12", time:"09:30", title:"Passeggiata sull'isola e cervi", sub:"Miyajima", cat:"nature", dur:90, tmode:"walk", tmin:0, notes:"Attenti ai cervi liberi, sono piuttosto confidenti.", q:"Miyajima Island", lat:34.2937, lon:132.3193},
    {id:"s1202", img:"itsukushima", day:"d12", time:"14:00", title:"Giornata libera, senza programma", sub:"Miyajima", cat:"experience", dur:150, tmode:"walk", tmin:0, notes:"Il giorno più tranquillo del viaggio: bene così dopo tante tappe fitte.", q:"Miyajima Island", lat:34.2937, lon:132.3193},

    // Day 13 — Dotonbori & Shinsekai (17/05)
    {id:"s1301", img:"transfer-generic", day:"d13", time:"10:00", title:"Trasferimento a Osaka", sub:"Miyajima → Osaka", cat:"transfer", dur:120, tmode:"metro", tmin:0, notes:"", q:"Osaka Station", lat:34.701497, lon:135.494717},
    {id:"s1302", img:"hotel-generic", day:"d13", time:"14:00", title:"Check-in Moxy Osaka Honmachi by Marriott", sub:"Osaka", cat:"hotel", dur:30, tmode:"walk", tmin:0, notes:"", q:"Moxy Osaka Honmachi by Marriott", lat:34.685873, lon:135.506127},
    {id:"s1303", img:"shinsekai", day:"d13", time:"17:00", title:"Shinsekai", sub:"Osaka", cat:"experience", dur:60, tmode:"metro", tmin:25, notes:"Il quartiere vintage con la Tsutenkaku Tower.", q:"Shinsekai, Osaka", lat:34.65209, lon:135.506191},
    {id:"s1304", img:"dotonbori", day:"d13", time:"19:30", title:"Dotonbori", sub:"Osaka", cat:"food", dur:120, tmode:"walk", tmin:20, notes:"Street food, luci al neon e il celebre cartellone Glico. Ultima serata di viaggio insieme.", q:"Dotonbori, Osaka", lat:34.669031, lon:135.501572},

    // Day 14 — Rientro (18/05)
    {id:"s1401", img:"transfer-generic", day:"d14", time:"06:30", title:"Checkout & trasferimento a Kansai Airport", sub:"Osaka → Kansai Airport (KIX)", cat:"transfer", dur:60, tmode:"car", tmin:0, notes:"⚠️ Partenza dall'hotel molto presto: il volo interno delle 09:20 non lascia tempo libero al mattino. Niente shopping dell'ultimo minuto, meglio farlo il giorno prima.", q:"Kansai International Airport", lat:34.434204, lon:135.222523},
    {id:"s1402", img:"flight-generic", day:"d14", time:"09:20", title:"Volo interno Osaka → Tokyo Haneda", sub:"Kansai (KIX) → Tokyo Haneda (HND)", cat:"transfer", dur:75, tmode:"car", tmin:0, notes:"Volo di collegamento verso Haneda per il volo internazionale.", q:"Kansai International Airport", locked:true, lat:34.434204, lon:135.222523},
    {id:"s1403", img:"flight-generic", day:"d14", time:"12:45", title:"Volo Tokyo Haneda → Roma Fiumicino", sub:"Tokyo Haneda (HND) → Roma Fiumicino (FCO)", cat:"transfer", dur:765, tmode:"car", tmin:0, notes:"Arrivo previsto a Roma Fiumicino alle 20:30 (ora locale). Bentornati!", q:"Tokyo Haneda Airport", locked:true, lat:35.545692, lon:139.776099}
  ]
};
